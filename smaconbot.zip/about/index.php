<?php
	$dir = '../';
	require_once($dir.'connection.php');
	$title = 'About Us | ';
?>
<?php include($dir.'header.php'); ?>

    
    <!-- inner hero start -->
    <section class="inner-hero bg_img" data-background="<?php print $dir; ?>assets/images/frontend/breadcrumb/5fce3837032a51607350327.jpg">
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <h2 class="page-title">About</h2>
            <ul class="page-breadcrumb">
              <li><a href="<?php print $dir; ?>">Home</a></li>
              <li>About</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
    <!-- inner hero end -->
                        <section class="pt-120 pb-120 bg_img" data-background="<?php print $dir; ?>assets/images/frontend/how_work/5fce39883b22c1607350664.jpg">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-6 text-center">
            <div class="section-header">
              <h2 class="section-title"><span class="font-weight-normal">How</span> <b class="base--color">Smaconbot</b> <span class="font-weight-normal">Works</span></h2>
              <p>Get involved in any of the plans, Set up a BCH Smart Contract and earn daily profits.</p>
            </div>
          </div>
        </div><!-- row end -->
        <div class="row justify-content-center mb-none-30">
                    <div class="col-lg-4 col-md-6 work-item mb-30">
            <div class="work-card text-center">
              <div class="work-card__icon base--color">
                <i class="las la-user-plus"></i>                <span class="step-number">1</span>
              </div>
              <div class="work-card__content">
                <h4 class="base--color mb-3">Create</h4>
              </div>
            </div><!-- work-card end -->
          </div>
                    <div class="col-lg-4 col-md-6 work-item mb-30">
            <div class="work-card text-center">
              <div class="work-card__icon base--color">
                <i class="las la-chart-bar"></i>                <span class="step-number">2</span>
              </div>
              <div class="work-card__content">
                <h4 class="base--color mb-3">Invest To Plans</h4>
              </div>
            </div><!-- work-card end -->
          </div>
                    <div class="col-lg-4 col-md-6 work-item mb-30">
            <div class="work-card text-center">
              <div class="work-card__icon base--color">
                <i class="las la-coins"></i>                <span class="step-number">3</span>
              </div>
              <div class="work-card__content">
                <h4 class="base--color mb-3">Earn Profit</h4>
              </div>
            </div><!-- work-card end -->
          </div>
                  </div>
      </div>
    </section>                    <section class="about-section pt-120 pb-120 bg_img" data-background="<?php print $dir; ?>assets/images/frontend/about/5fce36fe9c4561607350014.jpg">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 offset-lg-6">
            <div class="about-content">
              <h2 class="section-title mb-3"><span class="font-weight-normal"><b class="base--color">About Us</b></h2>
              <p>As the world today is investing in Smart Contract technology and Artificial Intelligence in building a State-Backed digital Currencies.
Smaconbot examined how Smart Contract System can help investors earn profits on daily basis without stress.
Smart Contract Systems are basically designed to carry out a set of instructions that help individuals or organisations multiply their earnings and increase Return on Investment (ROI).
Those behind Smaconbot work day and night to make trading a marketplace because we believe Smart Contract is the future of trading in the world economy in time to come.<br />

With this we believe Smaconbot will play an increasingly important role in the trading infrastructure of the digital economy from the establishment of the Smart-Contract technology. The system as built will enable investors to establish a partnership in helping banks around the world develop digital Assets in particular examining how smart contract technology can help crypto currency trading and individuals improve their earnings and lives in return as the system will do everything for you effortlessly.
<br/>
SMACONBOT is a financial rewarding platform leveraging on cryptocurency day trading to assist subscribers enjoy passive income stream on daily basis. On SMACONBOT, cryptocurrency trade is executed on an artificial intelligence system leveraging the BCH digital asset while rewarding subscribers 2.7% - 5% daily returns on their investments for the period of Investment Plan of 2 Months. Investments on SMACONBOT are tailored to meet all subscribers' budgets with our various investment plans.
<br/>
Daily returns on investments are automatically credited to subscribers accounts across the system without the need for withdrawal requests by account holders on SMACONBOT. Returns are automatically credited to subscribers everyday of the week excluding the weekends (Saturdays and Sundays). 
A one time Administrative fee of 5% will be charged on  investment plans for the maintenance and service of our system to allow subscribers enjoy smooth, fast and  24/7 functionality of our system.
</p>
             
            </div>
          </div>
        </div>
      </div>
    </section>




 <section class="pt-120 pb-120">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-6 text-center">
            <div class="section-header">
              <h2 class="section-title"><span class="font-weight-normal">Frequently Asked</span> <b class="base--color">Questions</b></h2>
              <p>Your Frequently asked Questions regarding the system are been answered. Assuring clear understanding and easy access.</p>
            </div>
          </div>
        </div><!-- row end -->
        <div class="row justify-content-center">
          <div class="col-lg-8">
            <div class="accordion cmn-accordion" id="accordionExample">
              <div class="card">
                <div class="card-header" id="heading0">
                  <h2 class="mb-0">
                    <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapse0" aria-expanded="false" aria-controls="collapse0">
                      <i class="las la-question-circle"></i>
                      <span>How can I be part of Smaconbot?</span>
                    </button>
                  </h2>
                </div>
            
                <div id="collapse0" class="collapse" aria-labelledby="heading0" data-parent="#accordionExample" style="">
                  <div class="card-body">
                    To be part of this system! Fund BCH in your Trust wallet . Create an account with Smaconbot choose any investment packs. Invest and you automatically set up a daily earning BCH Smart Contract.                 </div>
                </div>
              </div>
                            <div class="card">
                <div class="card-header" id="heading1">
                  <h2 class="mb-0">
                    <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapse1" aria-expanded="false" aria-controls="collapse1">
                      <i class="las la-question-circle"></i>
                      <span>How do I withdraw my investment?</span>
                    </button>
                  </h2>
                </div>
            
                <div id="collapse1" class="collapse" aria-labelledby="heading1" data-parent="#accordionExample" style="">
                  <div class="card-body">
                    The system is fully automated so you don’t have to stress yourself. 2.7% to 5% profits drops in your wallet everyday till your contract expires.                  </div>
                </div>
              </div>
                            <div class="card">
                <div class="card-header" id="heading2">
                  <h2 class="mb-0">
                    <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapse2" aria-expanded="false" aria-controls="collapse2">
                      <i class="las la-question-circle"></i>
                      <span>How long do my Contract stays before it expires?</span>
                    </button>
                  </h2>
                </div>
            
                <div id="collapse2" class="collapse" aria-labelledby="heading2" data-parent="#accordionExample" style="">
                  <div class="card-body">
                    Smaconbot active and run your contract for Two(2) months. Earning you daily profits and terminates the contract after 2 months.                 </div>
                </div>
              </div>
                            <div class="card">
                <div class="card-header" id="heading3">
                  <h2 class="mb-0">
                    <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapse3" aria-expanded="false" aria-controls="collapse3">
                      <i class="las la-question-circle"></i>
                      <span>Do I have to refer before I earn & how do I refer?</span>
                    </button>
                  </h2>
                </div>
            
                <div id="collapse3" class="collapse" aria-labelledby="heading3" data-parent="#accordionExample" style="">
                  <div class="card-body">
                     Referral has nothing to do with your investment. You automatically get daily profits   After investment. You can as well share the good news to your friends and family and get instant profit till 3rd generations referral.                  </div>
                </div>
              </div>
                            <div class="card">
                <div class="card-header" id="heading4">
                  <h2 class="mb-0">
                    <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapse4" aria-expanded="false" aria-controls="collapse4">
                      <i class="las la-question-circle"></i>
                      <span>How can I retrieve my password?</span>
                    </button>
                  </h2>
                </div>
            
                <div id="collapse4" class="collapse" aria-labelledby="heading4" data-parent="#accordionExample" style="">
                  <div class="card-body">
                    Visit the login page on Smaconbot!  Click on Forgot password Go to your email to reset and change password.</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>                    
	<section class="pb-120">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-xl-8">
            <div class="cta-wrapper bg_img border-radius--10 text-center" data-background="<?php print $dir; ?>assets/images/frontend/cta/5fce38bab36371607350458.jpg">
              <h2 class="title mb-3">Get Started With Us</h2>
              <p>Per-take In revolutional crypto Smart contract giving you anonymous delivery and excited return of investment. Making every day of the month favorable and profitable.</p>
              <a href="<?php print $dir; ?>register" class="cmn-btn mt-4">Join Us</a>
            </div>
          </div>
        </div>
      </div>
    </section>            
    
<?php include($dir.'footer.php'); ?>