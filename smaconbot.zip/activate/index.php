<?php
	$dir = '../';
	require_once($dir.'connection.php');
	
	if(!empty($_GET['usrid'])){
		$userId = $_GET['usrid'];
		$queryUser = mysqli_query($conn, "SELECT * FROM tbl_users WHERE unique_id='$userId'");
		if(mysqli_num_rows($queryUser) > 0){
			$code = mysqli_fetch_assoc($queryUser);
			if($code['email_verified'] == 'Yes'){
				$body = '<div class="main-wrapper login-body">
					<div class="login-wrapper">
						<div class="container">
							<div class="loginbox">
								<div class="login-left">
									<img class="img-fluid" src="'.$dir.'assets/images/logoIcon/logo.png" alt="Logo">
								</div>
								<div class="login-right">
									<div class="login-right-wrap">
										<h1 class="text-warning"><strong><i class="fa fa-info"></i> NOTICE</strong></h1>
										Your account is already verified. Kindly login to gain full access to your dashboard.
										<br /><br /> <button class="btn btn-success" onClick="location.href=\''.$dir.'login\'"><i class="fa fa-sign-in"></i> Login Now</button> </form>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>';
			}
			else{
				/////activate the account and redirect user//////
				$update = mysqli_query($conn, "UPDATE tbl_users SET email_verified='Yes' WHERE unique_id='$userId' LIMIT 1");
				if($update===true){
					$_SESSION['smaconbot_user'] = $code['unique_id'];
					$body = '<div class="main-wrapper login-body">
						<div class="login-wrapper">
							<div class="container">
								<div class="loginbox">
									<div class="login-left">
										<img class="img-fluid" src="'.$dir.'assets/images/logoIcon/logo.png" alt="Logo">
									</div>
									<div class="login-right">
										<div class="login-right-wrap">
											<h1 class="text-success"><strong><i class="fa fa-check"></i> ACCOUNT ACTIVATED</strong></h1>
											Hello <strong>'.$code['first_name'].'</strong>, thank you for verifying your account. You can now login to your dashboard to update your wallet address and start making investments. Click the button below to access your dashboard now.
											<br /><br /> <button class="btn btn-success" onClick="location.href=\''.$dir.'user\';"><i class="fa fa-techometer"></i> Go to My Dashboard</button>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>';
				}
			}
		}
		else{
			$body = '<div class="main-wrapper login-body">
				<div class="login-wrapper">
					<div class="container">
						<div class="loginbox">
							<div class="login-left">
								<img class="img-fluid" src="'.$dir.'assets/images/logoIcon/logo.png" alt="Logo">
							</div>
							<div class="login-right">
								<div class="login-right-wrap">
									<h1 class="text-danger"><strong><i class="fa fa-times"></i> ERROR OCCURRED!</strong></h1>
									We have encountered an error while trying to activate you account. This could be due to a broken link or trying to access this page directly. Kindly check your email and click on the ACTIVATE NOW button to activate your account.
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>';
		}
	}
else{
	header("Location: $dir");
}
	

	if(isset($_POST['homeBtn'])){
		unset($_SESSION['registered']);
		header("Location: $dir");
	}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <title>Activate Account | SmaconBot - The world's most robust trading technology</title>
		
		<!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="<?php print $dir; ?>assets/images/logoIcon/favicon.png">

		<!-- Bootstrap CSS -->
        <link rel="stylesheet" href="<?php print $dir; ?>login-assets/css/bootstrap.min.css">
		
		<!-- Fontawesome CSS --> 
		<link rel="stylesheet" href="<?php print $dir; ?>login-assets/plugins/fontawesome/css/fontawesome.min.css">
		<link rel="stylesheet" href="<?php print $dir; ?>login-assets/plugins/fontawesome/css/all.min.css">
		
		<!-- Feathericon CSS -->
        <link rel="stylesheet" href="<?php print $dir; ?>login-assets/css/feather.css">
		
		<!-- Main CSS -->
        <link rel="stylesheet" href="<?php print $dir; ?>login-assets/css/style.css">
		
		<!--[if lt IE 9]>
			<script src="assets/js/html5shiv.min.js"></script>
			<script src="assets/js/respond.min.js"></script>
		<![endif]-->
    </head>
    <body>
	
		<!-- Main Wrapper -->
        <?php print $body; ?>
		<!-- /Main Wrapper -->
		
		<!-- jQuery -->
        <script src="<?php print $dir; ?>login-assets/js/jquery-3.2.1.min.js"></script>
		
		<!-- Bootstrap Core JS -->
        <script src="<?php print $dir; ?>login-assets/js/popper.min.js"></script>
        <script src="<?php print $dir; ?>login-assets/js/bootstrap.min.js"></script>
		
		<!-- Custom JS -->
		<script src="<?php print $dir; ?>login-assets/js/script.js"></script>
		
    </body>
</html>