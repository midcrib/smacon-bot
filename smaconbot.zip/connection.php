<?php
error_reporting(0);
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbName = "smaconbot";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbName);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

	$webUrl = 'https://smaconbot.midcrib.co.uk/';
	$mailLink = 'smaconbot.midcrib.co.uk';

	date_default_timezone_set('Africa/Lagos');
	
	$regNew = $_SESSION['regCodeSet'];

	$baseUrl = 'http://localhost/ebsirsapp/main-ebsirb-system/';

	function currentPageURL(){
		$PageURL = 'http';
	 if ($_SERVER["HTTPS"] == "on"){
		$PageURL .= "s";
	 }
	 
	 $PageURL .= "://";
	 if ($_SERVER["SERVER_PORT"] != "80"){
		$PageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
	 }
	 else{
		$PageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
	 }
	 return $PageURL;
	}

	$url = currentPageURL();
	
	if (!empty($_SERVER["HTTP_CLIENT_IP"])){
	 //check for ip from share internet
	 $ip = $_SERVER["HTTP_CLIENT_IP"];
	}
	elseif (!empty($_SERVER["HTTP_X_FORWARDED_FOR"])){
	 // Check for the Proxy User
	 $ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
	}
	else{
	 $ip = $_SERVER["REMOTE_ADDR"];
	}
	
	$ipAddress = $ip;
	$smaconbotUser = $_SESSION['smaconbot_user'];

	//////get the user details////////
	$queryUserDetail = mysqli_query($conn, "SELECT * FROM tbl_users WHERE unique_id='$smaconbotUser' LIMIT 1");
	$user = mysqli_fetch_assoc($queryUserDetail);
	if($user['image'] ==''){
		$profileImage = 'default.png';
	}
	else{
		$profileImage = $user['image'];
	}

	//////get user payment///////
	$queryPayments = mysqli_query($conn, "SELECT * FROM tbl_payments WHERE user_id='$smaconbotUser'");
	
	$queryUserAddr = mysqli_query($conn, "SELECT * FROM tbl_usr_address WHERE user_id='$smaconbotUser'");

	//////Get user image/////
	$profileImage = 'default.png';
	
	/////logout script///
	if(!empty($_GET['logout'])){
		session_destroy();
		header("Location: $dir");
	}
?>