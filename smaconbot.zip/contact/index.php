<?php
	$dir = '../';
	require_once($dir.'connection.php');
	$title = 'Contact Us | ';
?>
<?php include($dir.'header.php'); ?>

        <!-- inner hero start -->
    <section class="inner-hero bg_img" data-background="<?php print $dir; ?>assets/images/frontend/breadcrumb/5fce3837032a51607350327.jpg">
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <h2 class="page-title">Contact Us</h2>
            <ul class="page-breadcrumb">
              <li><a href="index.html">Home</a></li>
              <li>Contact Us</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
    <!-- inner hero end -->     <!-- contact section start -->
    <section class="pt-120 pb-120">
      <div class="container">
        <div class="contact-wrapper">
          <div class="row">
            <div class="col-lg-6 contact-thumb bg_img" data-background="<?php print $dir; ?>assets/images/frontend/contact/5fce3861b2a1c1607350369.jpg"></div>
            <div class="col-lg-6 contact-form-wrapper">
              <h2 class="font-weight-bold mb-2">Contact Us</h2>
              <p class="font-weight-bold"> We are at your service. Do you have any questions or Need help. Contact our helpdesk. We will respond as soon as possible. Thanks.</p>
              <form action="#" method="post" class="contact-form mt-4">
                <input type="hidden" name="_token" value="D3IHHA1YZ1CpI8rjBXq4yXTLk2aj5tD1Gm1EZbI6">                <div class="form-row">
                  <div class="form-group col-lg-6">
                    <input type="text" name="name" placeholder="Full Name" class="form-control">
                  </div>
                  <div class="form-group col-lg-6">
                    <input type="email" name="email" placeholder="Email Address" class="form-control">
                  </div>
                  <div class="form-group col-lg-12">
                    <input name="subject" placeholder="Subject" class="form-control">
                  </div>
                  <div class="form-group col-lg-12">
                    <textarea class="form-control" name="message" placeholder="Message"></textarea>
                  </div>
                  <div class="col-lg-12">
                    <button type="submit" class="cmn-btn">Send Message</button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div><!-- contact-wrapper end -->
      </div>
      <div class="container pt-120">
        <div class="row justify-content-center">
          <div class="col-lg-10">
            <div class="row mb-none-30">
              <div class="col-md-4 col-sm-6 mb-30">
                <div class="contact-item">
                  <i class="las la-phone"></i><h5 class="mt-2"> Phone Number</h5>
                  <div class="mt-4">
                    <p><a href="javascript:void(0)">+01234 5678 9000</a></p>
                  </div>
                </div><!-- contact-item end -->
              </div>
              <div class="col-md-4 col-sm-6 mb-30">
                <div class="contact-item">
                  <i class="las la-envelope-open"></i>                  <h5 class="mt-2">Email Address</h5>
                  <div class="mt-4">
                    <p><a href="javascript:void(0)">Info@Smaconbot.com</a></p>
                  </div>
                </div><!-- contact-item end -->
              </div>
              <div class="col-md-4 col-sm-6 mb-30">
                <div class="contact-item">
                  <i class="las la-map-marker"></i>                  <h5 class="mt-2">Office Address</h5>
                  <div class="mt-4">
                    <p><a href="javascript:void(0)">98108-1226 Seattle, WA, United State</a></p>
                  </div>
                </div><!-- contact-item end -->
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- contact section end -->

<?php include($dir.'footer.php'); ?>