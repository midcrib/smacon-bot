<!-- meta tags and other links -->
<!DOCTYPE html>
<html lang="en">

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="csrf-token" content="D3IHHA1YZ1CpI8rjBXq4yXTLk2aj5tD1Gm1EZbI6">
    <title><?php print $title; ?>SmaconBot - The world's most robust trading technology</title>
    <meta name="description" content="Smaconbot is world’s most robust crypto technology. Decentralized trading system with artificial intelligence in Crypto BCH smart contract. A unique Traders with artificial intelligence delivering anonymous daily financial results. Aim to build world Crypto millionaires.">
    <meta name="keywords" content="smacon bot, smaconbot">
    <link rel="shortcut icon" href="<?php print $dir; ?>assets/images/logoIcon/favicon.png" type="image/x-icon">

    
    <link rel="apple-touch-icon" href="<?php print $dir; ?>assets/images/logoIcon/logo.png">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="Cadony - Home">
    
    <meta itemprop="name" content="Cadony - Home">
    <meta itemprop="description" content="">
    <meta itemprop="image" content="<?php print $dir; ?>assets/images/seo/5fcc92c79ffe31607242439.jpg">
    
    <meta property="og:type" content="website">
    <meta property="og:title" content="Smaconbot...The world most robust crypto technology">
    <meta property="og:description" content="Smaconbot...The world most robust crypto technology">
    <meta property="og:image" content="<?php print $dir; ?>assets/images/seo/5fcc92c79ffe31607242439.jpg"/>
    <meta property="og:image:type" content="image/jpg" />
        <meta property="og:image:width" content="600" />
    <meta property="og:image:height" content="315" />
    <meta property="og:url" content="index.html">
    
  <meta name="twitter:card" content="summary_large_image">
  <!-- bootstrap 4  -->
  <link rel="stylesheet" href="<?php print $dir; ?>assets/templates/bit_gold/css/vendor/bootstrap.min.css">
	<!-- Font awesome icons -->
    <link href="<?php print $dir; ?>assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php print $dir; ?>assets/css/font-awesome-animation.min.css" rel="stylesheet">
  <!-- fontawesome 5  -->
  <link rel="stylesheet" href="<?php print $dir; ?>assets/templates/bit_gold/css/all.min.css">
  <!-- line-awesome webfont -->
  <link rel="stylesheet" href="<?php print $dir; ?>assets/templates/bit_gold/css/line-awesome.min.css">
  <link rel="stylesheet" href="<?php print $dir; ?>assets/templates/bit_gold/css/vendor/animate.min.css">
  <!-- slick slider css -->
  <link rel="stylesheet" href="<?php print $dir; ?>assets/templates/bit_gold/css/vendor/slick.css">
  <link rel="stylesheet" href="<?php print $dir; ?>assets/templates/bit_gold/css/vendor/dots.css">
      <!-- dashdoard main css -->
  <link rel="stylesheet" href="<?php print $dir; ?>assets/templates/bit_gold/css/main.css">
  <link rel="stylesheet" href="<?php print $dir; ?>assets/templates/bit_gold/css/custom.css">
  <link rel="stylesheet" href="<?php print $dir; ?>assets/templates/bit_gold/css/color9bce.css?color=CCA354&amp;secondColor=000000">
  <!--Start of Tawk.to Script-->
	<script type="text/javascript">
	var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
	(function(){
	var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
	s1.async=true;
	s1.src='https://embed.tawk.to/609714e2185beb22b30b7080/1f572j5jr';
	s1.charset='UTF-8';
	s1.setAttribute('crossorigin','*');
	s0.parentNode.insertBefore(s1,s0);
	})();
	</script>
	<!--End of Tawk.to Script-->
	
	</head>
  <body>
    
  
    <!-- scroll-to-top start -->
    <div class="scroll-to-top">
      <span class="scroll-icon">
        <i class="fa fa-rocket" aria-hidden="true"></i>
      </span>
    </div>
    <!-- scroll-to-top end -->

  <div class="full-wh">
    <!-- STAR ANIMATION -->
    <div class="bg-animation">
      <div id='stars'></div>
      <div id='stars2'></div>
      <div id='stars3'></div>
      <div id='stars4'></div>
    </div><!-- / STAR ANIMATION -->
  </div>
  <div class="page-wrapper">
      <!-- header-section start  -->
  <header class="header">
    <div class="header__bottom">
      <div class="container">
        <nav class="navbar navbar-expand-xl p-0 align-items-center">
          <a class="site-logo site-title" href="<?php print $dir; ?>"><img src="<?php print $dir; ?>assets/images/logoIcon/logo.png" alt="site-logo"></a>
          <ul class="account-menu responsive-account-menu ml-3">
			<li class="icon"><a href="<?php print $dir; ?>login"><i class="las la-user"></i></a></li>
		  </ul> 
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="menu-toggle"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav main-menu ml-auto">
              <li> <a href="<?php print $dir; ?>">Home</a></li>
              <li><a href="<?php print $dir; ?>plan">Plan</a></li>
              <li><a href="<?php print $dir; ?>about">About</a></li>
              <li><a href="#">Blog</a></li>
              <li><a href="<?php print $dir; ?>contact">Contact</a></li>
            </ul>
            <div class="nav-right">
              <ul class="account-menu ml-3">
				<?php
				  	if(!empty($_SESSION['smaconbot_user'])){
					  	print '<li class="icon"><a href="'.$dir.'user"><i class="las la-user"></i></a></li>';
				  	}
					else{
						 print '<li class="icon"><a href="'.$dir.'login"><i class="las la-user"></i></a></li>';
					 }
				?>
			  </ul> 
              <select class="select d-inline-block w-auto ml-xl-3 langSel">
				  <option value="en"  selected  >English</option>
			  </select>
            </div>
          </div>
        </nav>
      </div>
    </div><!-- header__bottom end -->
  </header>
  <!-- header-section end  -->