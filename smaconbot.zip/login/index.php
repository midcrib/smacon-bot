<?php
	$dir = '../';
	require_once($dir.'connection.php');

	if(!empty($_SESSION['smaconbot_user'])){
		header("Location: $dir"."user");
	}

	$msg = '<p class="account-subtitle">Access to our dashboard</p>';
	$body = '<div class="main-wrapper login-body" >
			<div class="login-wrapper">
				<div class="container">
					<div class="loginbox">
						<div class="login-left">
							<img class="img-fluid" src="'.$dir.'assets/images/logoIcon/logo.png" alt="Logo">
						</div>
						<div class="login-right">
							<div class="login-right-wrap">
								<h1>Login</h1>
								'.$msg.'

								<!-- Form -->
								<form method="post">
									<div class="form-group">
										<input class="form-control" type="text" name="username" placeholder="Enter username">
									</div>
									<div class="form-group">
										<input class="form-control" type="password" name="password" placeholder="Enter Password">
									</div>
									<div class="form-group">
										<button class="btn btn-primary btn-block" type="submit" name="loginBtn">Login</button>
									</div>
								</form>
								<!-- /Form -->

								<div class="text-center forgotpass"><a href="'.$dir.'forgot-password">Forgot Password?</a></div>
								<div class="login-or">
									<span class="or-line"></span>
									<span class="span-or"></span>
								</div>

								<div class="text-center dont-have">Don’t have an account? <a href="'.$dir.'register">Register</a></div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>';
	
	if(isset($_POST['loginBtn'])){
		$username = mysqli_real_escape_string($conn, $_POST['username']);
		$password = mysqli_real_escape_string($conn, $_POST['password']);
		
		$queryUser = mysqli_query($conn, "SELECT * FROM tbl_users WHERE username='$username'");
		if(mysqli_num_rows($queryUser) > 0){
			$userDet = mysqli_fetch_assoc($queryUser);
			$password = md5($userDet['added_on'].$password.$userDet['added_on']);
			
			$queryLogin = mysqli_query($conn, "SELECT * FROM tbl_users WHERE username='$username' AND password='$password'");
			if(mysqli_num_rows($queryLogin) > 0){
				$userStat = mysqli_fetch_assoc($queryLogin);
				//////set the login user session and log the user in/////
				if($userStat['email_verified'] == 'Yes'){
					$_SESSION['smaconbot_user'] = $userStat['unique_id'];
				
					$body = '<div class="main-wrapper login-body" >
						<div class="login-wrapper">
							<div class="container">
								<div class="loginbox">
									<div class="login-left">
										<img class="img-fluid" src="'.$dir.'assets/images/logoIcon/logo.png" alt="Logo">
									</div>
									<div class="login-right">
										<div class="login-right-wrap">
											<h1 class="text-success"><i class="fa fa-check"></i> LOGIN SUCCESSFUL</h1>
											<p class="text-center">
												Your login was successful. Please wait while we load your dashboard...
												<h1 class="text-success"><i class="fa fa-spinner fa-spin"></i></h1
											</p>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>';
					header("refresh: 4; url=$dir"."user");
				}
				else{
					$body = '<div class="main-wrapper login-body" >
						<div class="login-wrapper">
							<div class="container">
								<div class="loginbox">
									<div class="login-left">
										<img class="img-fluid" src="'.$dir.'assets/images/logoIcon/logo.png" alt="Logo">
									</div>
									<div class="login-right">
										<div class="login-right-wrap">
											<h1 class="text-warning"><i class="fa fa-info"></i> IMPORTANT NOTICE</h1>
											<p class="text-center">
												Dear <strong>'.$userStat['first_name'].'</strong>, you are yet to verify your email address. Kindly check your mailbox for activation link or send a message to <strong>admin@smaconbot.com</strong>
											</p>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>';
				}
			}
			else{
				$msg = '<p class="account-subtitle text-danger">Invalid Username/Password</p>';
				$body = '<div class="main-wrapper login-body" >
					<div class="login-wrapper">
						<div class="container">
							<div class="loginbox">
								<div class="login-left">
									<img class="img-fluid" src="'.$dir.'assets/images/logoIcon/logo.png" alt="Logo">
								</div>
								<div class="login-right">
									<div class="login-right-wrap">
										<h1>Login</h1>
										'.$msg.'
										<!-- Form -->
										<form method="post">
											<div class="form-group">
												<input class="form-control" type="text" value="'.$_POST['username'].'"  name="username" placeholder="Enter username">
											</div>
											<div class="form-group">
												<input class="form-control" type="password" value="'.$_POST['password'].'" name="password" placeholder="Enter Password">
											</div>
											<div class="form-group">
												<button class="btn btn-primary btn-block" type="submit" name="loginBtn">Login</button>
											</div>
										</form>
										<!-- /Form -->

										<div class="text-center forgotpass"><a href="'.$dir.'forgot-password">Forgot Password?</a></div>
										<div class="login-or">
											<span class="or-line"></span>
											<span class="span-or"></span>
										</div>

										<div class="text-center dont-have">Don’t have an account? <a href="'.$dir.'register">Register</a></div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>';
			}
		}
		else{
			$msg = '<p class="account-subtitle text-danger">Invalid Username/Password - user not found</p>';
			$body = '<div class="main-wrapper login-body" >
					<div class="login-wrapper">
						<div class="container">
							<div class="loginbox">
								<div class="login-left">
									<img class="img-fluid" src="'.$dir.'assets/images/logoIcon/logo.png" alt="Logo">
								</div>
								<div class="login-right">
									<div class="login-right-wrap">
										<h1>Login</h1>
										'.$msg.'

										<!-- Form -->
										<form method="post">
											<div class="form-group">
												<input class="form-control" type="text" value="'.$_POST['username'].'"  name="username" placeholder="Enter username">
											</div>
											<div class="form-group">
												<input class="form-control" type="password" value="'.$_POST['password'].'" name="password" placeholder="Enter Password">
											</div>
											<div class="form-group">
												<button class="btn btn-primary btn-block" type="submit" name="loginBtn">Login</button>
											</div>
										</form>
										<!-- /Form -->

										<div class="text-center forgotpass"><a href="'.$dir.'forgot-password">Forgot Password?</a></div>
										<div class="login-or">
											<span class="or-line"></span>
											<span class="span-or"></span>
										</div>

										<div class="text-center dont-have">Don’t have an account? <a href="'.$dir.'register">Register</a></div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>';
		}
		
	}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <title>Login | SmaconBot - The world\'s most robust trading technology</title>
		
		<!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="<?php print $dir; ?>assets/images/logoIcon/favicon.png">

		<!-- Bootstrap CSS -->
        <link rel="stylesheet" href="<?php print $dir; ?>login-assets/css/bootstrap.min.css">
		
		<!-- Fontawesome CSS --> 
		<link rel="stylesheet" href="<?php print $dir; ?>login-assets/plugins/fontawesome/css/fontawesome.min.css">
		<link rel="stylesheet" href="<?php print $dir; ?>login-assets/plugins/fontawesome/css/all.min.css">
		
		<!-- Feathericon CSS -->
        <link rel="stylesheet" href="<?php print $dir; ?>login-assets/css/feather.css">
		
		<!-- Main CSS -->
        <link rel="stylesheet" href="<?php print $dir; ?>login-assets/css/style.css">
		
		<!--[if lt IE 9]>
			<script src="assets/js/html5shiv.min.js"></script>
			<script src="assets/js/respond.min.js"></script>
		<![endif]-->
    </head>
    <body>
	
		<!-- Main Wrapper -->
        <?php print $body; ?>
		<!-- /Main Wrapper -->
		
		<!-- jQuery -->
        <script src="<?php print $dir; ?>login-assets/js/jquery-3.2.1.min.js"></script>
		
		<!-- Bootstrap Core JS -->
        <script src="<?php print $dir; ?>login-assets/js/popper.min.js"></script>
        <script src="<?php print $dir; ?>login-assets/js/bootstrap.min.js"></script>
		
		<!-- Custom JS -->
		<script src="<?php print $dir; ?>login-assets/js/script.js"></script>
		
    </body>
</html>