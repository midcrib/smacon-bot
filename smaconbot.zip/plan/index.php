<?php
	$dir = '../';
	require_once($dir.'connection.php');
	$title = 'Investment Plans | ';
?>
<?php include($dir.'header.php'); ?>
    <!-- inner hero start -->
    <section class="inner-hero bg_img" data-background="<?php print $dir; ?>assets/images/frontend/breadcrumb/5fce3837032a51607350327.jpg">
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <h2 class="page-title">Investment Packs</h2>
            <ul class="page-breadcrumb">
              <li><a href="<?php print $dir; ?>">Home</a></li>
              <li>Investment Packs</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
    <!-- inner hero end --> <section class="pt-120 pb-120">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-6 text-center">
            <div class="section-header">
              <h2 class="section-title"><span class="font-weight-normal">Investment</span> <b class="base--color">Plans</b></h2>
              <p>It is the user’s responsibility to ensure compliance with applicable local or national laws before registering with smaconbot does not accept any liability for non-compliance with applicable local or national laws. SMACONBOT does not accept any fiat currencies such as dollar, euro, yen, naira, or any other government’s currencies. SMACONBOT is a high-risk entertainment system based on cryptocurrency.</p>
			  
			  
            </div>
          </div>
        </div><!-- row end --><!-- row end -->
        <div class="row mb-none-30 justify-content-center">
                                <div class="col-lg-3 mb-30">
            <div class="package-card text-center bg_img" data-background="<?php print $dir; ?>assets/templates/bit_gold/images/bg/bg-4.gif">
              <h4 class="package-card__title base--color mb-2">Basic Plan</h4>
              
              <ul class="package-card__features mt-4">

                <li>RETURNS</li>
                
                <li>
                  2.7% TO 5% PER DAY EARNING
                </li>
                <li>FOR 2 MONTHS</li>
                <li> 
                    TOTAL 40%

                                        + <span class="badge badge-success">Capital</span> 
                                        </li>
              </ul>
              <div class="package-card__range mt-5 base--color">                .10 BCH
                              </div>
              <a href="javascript:void(0)" data-toggle="modal" data-target="#depoModal" data-resource="{&quot;id&quot;:1,&quot;name&quot;:&quot;Gold&quot;,&quot;minimum&quot;:&quot;524.20&quot;,&quot;maximum&quot;:&quot;524.20&quot;,&quot;fixed_amount&quot;:&quot;524.20&quot;,&quot;interest&quot;:&quot;10&quot;,&quot;interest_status&quot;:&quot;1&quot;,&quot;times&quot;:&quot;720&quot;,&quot;status&quot;:&quot;1&quot;,&quot;featured&quot;:&quot;1&quot;,&quot;capital_back_status&quot;:&quot;1&quot;,&quot;lifetime_status&quot;:&quot;0&quot;,&quot;repeat_time&quot;:&quot;12&quot;,&quot;created_at&quot;:&quot;2021-04-15T13:47:57.000000Z&quot;,&quot;updated_at&quot;:&quot;2021-04-15T13:47:57.000000Z&quot;}" class="cmn-btn btn-md mt-4 investButton">Invest Now</a>
            </div><!-- package-card end -->
          </div>
                                <div class="col-lg-3 mb-30">
            <div class="package-card text-center bg_img" data-background="<?php print $dir; ?>assets/templates/bit_gold/images/bg/bg-4.gif">
              <h4 class="package-card__title base--color mb-2">Standard Plan</h4>
              
              <ul class="package-card__features mt-4">

                <li>RETURNS</li>
                
                <li>
                  2.7% TO 5% PER DAY EARNING
                </li>
                <li>FOR 2 MONTHS</li>
                <li> 
                    TOTAL 40%

                                        + <span class="badge badge-success">Capital</span> 
                                        </li>
              </ul>
              <div class="package-card__range mt-5 base--color">                .20 BCH
                              </div>
              <a href="javascript:void(0)" data-toggle="modal" data-target="#depoModal" data-resource="{&quot;id&quot;:2,&quot;name&quot;:&quot;Platinum&quot;,&quot;minimum&quot;:&quot;393.15&quot;,&quot;maximum&quot;:&quot;393.15&quot;,&quot;fixed_amount&quot;:&quot;393.15&quot;,&quot;interest&quot;:&quot;10&quot;,&quot;interest_status&quot;:&quot;1&quot;,&quot;times&quot;:&quot;720&quot;,&quot;status&quot;:&quot;1&quot;,&quot;featured&quot;:&quot;1&quot;,&quot;capital_back_status&quot;:&quot;1&quot;,&quot;lifetime_status&quot;:&quot;0&quot;,&quot;repeat_time&quot;:&quot;9&quot;,&quot;created_at&quot;:&quot;2021-04-15T13:48:42.000000Z&quot;,&quot;updated_at&quot;:&quot;2021-04-15T13:48:42.000000Z&quot;}" class="cmn-btn btn-md mt-4 investButton">Invest Now</a>
            </div><!-- package-card end -->
          </div>
                                <div class="col-lg-3 mb-30">
            <div class="package-card text-center bg_img" data-background="<?php print $dir; ?>assets/templates/bit_gold/images/bg/bg-4.gif">
              <h4 class="package-card__title base--color mb-2">Premium Plan</h4>
              
              <ul class="package-card__features mt-4">

                <li>RETURNS</li>
                
                <li>
                  2.7% TO 5% PER DAY EARNING
                </li>
                <li>FOR 2 MONTHS</li>
                <li> 
                    TOTAL 40%

                                        + <span class="badge badge-success">Capital</span> 
                                        </li>
              </ul>
              <div class="package-card__range mt-5 base--color">                UNLIMITED BCH
                              </div>
              <a href="javascript:void(0)" data-toggle="modal" data-target="#depoModal" data-resource="{&quot;id&quot;:3,&quot;name&quot;:&quot;Diamond&quot;,&quot;minimum&quot;:&quot;262.10&quot;,&quot;maximum&quot;:&quot;262.10&quot;,&quot;fixed_amount&quot;:&quot;262.10&quot;,&quot;interest&quot;:&quot;10&quot;,&quot;interest_status&quot;:&quot;1&quot;,&quot;times&quot;:&quot;720&quot;,&quot;status&quot;:&quot;1&quot;,&quot;featured&quot;:&quot;1&quot;,&quot;capital_back_status&quot;:&quot;1&quot;,&quot;lifetime_status&quot;:&quot;0&quot;,&quot;repeat_time&quot;:&quot;6&quot;,&quot;created_at&quot;:&quot;2021-04-15T13:49:20.000000Z&quot;,&quot;updated_at&quot;:&quot;2021-04-15T13:49:20.000000Z&quot;}" class="cmn-btn btn-md mt-4 investButton">Invest Now</a>
            </div><!-- package-card end -->
          </div>
                                
       </div>
      </div>
</section>
    
<?php include($dir.'footer.php'); ?>