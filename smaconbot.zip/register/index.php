<?php
	$dir = '../';
	require_once($dir.'connection.php');
	//

	$msg = '<p class="account-subtitle">Create New Account</p>';

	/////create new user account script////////
	if(isset($_POST['submitDetails'])){
		$firstName = mysqli_real_escape_string($conn, $_POST['f_name']);
		$lastName = mysqli_real_escape_string($conn, $_POST['l_name']);
		$username = mysqli_real_escape_string($conn, $_POST['username']);
		$phone = mysqli_real_escape_string($conn, $_POST['phone']);
		$email = mysqli_real_escape_string($conn, $_POST['email']);
		$password = mysqli_real_escape_string($conn, $_POST['password']);
		$cpassword = mysqli_real_escape_string($conn, $_POST['cpassword']);
		$referrer = mysqli_real_escape_string($conn, $_POST['referrer']);
		
		/////check added username/////
		if(empty($username)){
			$un_error = '* Enter Username';
		}
		else{
			if(mysqli_num_rows(mysqli_query($conn, "SELECT * FROM tbl_users WHERE username='$username'"))){
				$un_error = '* Username taken!';
			}
		}
		
		// Validate email
		if(empty($email)){
			$email_error = "Enter Email";
		}else{
			if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
				$email_error = '* Invalid email format.';
			}else{
				// Prepare a select statement
				if(mysqli_num_rows(mysqli_query($conn, "SELECT * FROM tbl_users WHERE email='$email'"))){
					$email_error = '* This email is already in use.';
				}
			}
		}
		
		if(empty($phone)){
			$phone_error = '* Enter Phone';
		}
		
		if(empty($firstName)){
			$fn_error = '* Enter First name';
		}
		if(empty($lastName)){
			$ln_error = '* Enter last name';
		}
		if(empty($country)){
			$c_error = '* Select country';
		}
		if(empty($password)){
			$pw_error = '* enter password';
		}
		
		if(empty($cpassword)){
			$cpw_error = '* confirm password';
		}
		else{
			if($password!=$cpassword){
				$cpw_error = '* password mismatch';
			}
		}
		
		$registeredOn = time();
		$password = md5($registeredOn.$password.$registeredOn);
		$uniqueId = md5($registeredOn);
		
		if(empty($un_error) && empty($email_error) && empty($fn_error) && empty($ln_error) && empty($pw_error) && empty($cpw_error) && empty($phone_error) && empty($phone_error)){
			/////insert record into the database///
			$insertQuery = mysqli_query($conn, "INSERT INTO tbl_users(unique_id, first_name, last_name, phone, username, email,	password, added_on, added_by, referred_by) VALUES('$uniqueId', '$firstName', '$lastName', '$phone', '$username', '$email', '$password', $registeredOn, 'Self Registration','$referrer')");
			
			if($insertQuery===true){
				
				@include $dir.'email.php';
				
				//Send activation email message
				$body = $activationMail;
				$to = $email; 
				$subject = "Account Activation Mail";
				$from = 'SmaconBot <no-reply@midcrib.co.uk>';
				$reply_to = 'no-reply@midcrib.co.uk';
				// To send HTML mail, the Content-type header must be set

				$headers  = 'MIME-Version: 1.0' . "\r\n";

				$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

				// Create email headers
				$headers .= 'From: '.$from."\r\n".
					'Reply-To: '.$reply_to."\r\n" .
					'X-Mailer: PHP/' . phpversion();

				// Sending email

				if(mail($to, $subject, $body, $headers)){
					$msg = '<p class="account-subtitle text-success">Account Created</p>';
					$_SESSION['registered'] = $email;
					header("refesh: 3; ./");
				}
				else{
					$msg = '<p class="account-subtitle text-warning">Account Created but activation mail was not sent.</p>';
					//$_SESSION['registered'] = $email;
					//header("refesh: 3; ./");
				}
			}
			else{
				$msg = '<p class="account-subtitle text-danger">Could not submit details. ('.mysqli_error($conn).')</p>';
			}
		}
	}

	if(isset($_POST['homeBtn'])){
		unset($_SESSION['registered']);
		header("Location: $dir");
	}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <title>Register | SmaconBot - The world's most robust trading technology</title>
		
		<!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="<?php print $dir; ?>assets/images/logoIcon/favicon.png">

		<!-- Bootstrap CSS -->
        <link rel="stylesheet" href="<?php print $dir; ?>login-assets/css/bootstrap.min.css">
		
		<!-- Fontawesome CSS --> 
		<link rel="stylesheet" href="<?php print $dir; ?>login-assets/plugins/fontawesome/css/fontawesome.min.css">
		<link rel="stylesheet" href="<?php print $dir; ?>login-assets/plugins/fontawesome/css/all.min.css">
		
		<!-- Feathericon CSS -->
        <link rel="stylesheet" href="<?php print $dir; ?>login-assets/css/feather.css">
		
		<!-- Main CSS -->
        <link rel="stylesheet" href="<?php print $dir; ?>login-assets/css/style.css">
		
		<!--[if lt IE 9]>
			<script src="assets/js/html5shiv.min.js"></script>
			<script src="assets/js/respond.min.js"></script>
		<![endif]-->
    </head>
    <body>
	
		<!-- Main Wrapper -->
        <div class="main-wrapper login-body">
            <div class="login-wrapper">
            	<div class="container">
                	<div class="loginbox">
                    	<div class="login-left">
							<img class="img-fluid" src="<?php print $dir; ?>assets/images/logoIcon/logo.png" alt="Logo">
                        </div>
						<?php if(empty($_SESSION['registered'])){ ?>
                        <div class="login-right">
							<div class="login-right-wrap">
								<h1>Register</h1>
								<?php print $msg; ?>
								
								<!-- Form -->
								<form method="post">
									<div class="form-group">
										<input class="form-control" name="f_name" value="<?php print $_POST['f_name']; ?>" type="text" placeholder="First Name">
										<small><span class="text-danger"><?php print $fn_error; ?></span></small>
									</div>
									
									<div class="form-group">
										<input class="form-control" name="l_name" value="<?php print $_POST['l_name']; ?>" type="text" placeholder="Last Name">
										<small><span class="text-danger"><?php print $ln_error; ?></span></small>
									</div>
									<div class="form-group">
										<input class="form-control" name="username" value="<?php print $_POST['username']; ?>" type="text" placeholder="Username">
										<small><span class="text-danger"><?php print $un_error; ?></span></small>
									</div>
									<div class="form-group">
										<input class="form-control" name="phone" value="<?php print $_POST['phone']; ?>" type="text" placeholder="Phone">
										<small><span class="text-danger"><?php print $phone_error; ?></span></small>
									</div>
									<div class="form-group">
										<input class="form-control" name="email" type="text" value="<?php print $_POST['email']; ?>" placeholder="Email">
										<small><span class="text-danger"><?php print $email_error; ?></span></small>
									</div>
									<div class="form-group">
										<input class="form-control" name="referrer" type="text" value="<?php print $_POST['referrer']; ?>" placeholder="Referrer username">
									</div>
									<div class="form-group">
										<select class="form-control" name="country">
											<option value="">Select country</option>
											<?php
												$queryCountry = mysqli_query($conn, "SELECT * FROM countries WHERE status=1 ORDER BY country_name ASC");
												 while($country = mysqli_fetch_assoc($queryCountry)){
													 print '<option value="'.$country['country_name'].'">'.$country['country_name'].'<option>';
												 }
											?>
										</select>
										<small><span class="text-danger"><?php print $c_error; ?></span></small>
									</div>
									<div class="form-group">
										<input class="form-control" name="password" value="<?php print $_POST['password']; ?>" type="password" placeholder="Password">
										<small><span class="text-danger"><?php print $pw_error; ?></span></small>
									</div>
									<div class="form-group">
										<input class="form-control" name="cpassword" value="<?php print $_POST['cpassword']; ?>" type="password" placeholder="Confirm Password">
										<small><span class="text-danger"><?php print $cpw_error; ?></span></small>
									</div>
									<div class="form-group mb-0">
										<button class="btn btn-primary btn-block" name="submitDetails" type="submit">Register</button>
									</div>
								</form>
								<!-- /Form -->
								
								<div class="login-or">
									<span class="or-line"></span>
									<span class="span-or"></span>
								</div>
								
								<div class="text-center dont-have">Already have an account? <a href="<?php print $dir; ?>login">Login</a></div>
							</div>
                        </div>
						<?php }else{ ?>
                        <div class="login-right">
							<div class="login-right-wrap">
								<h1 class="text-success"><strong><i class="fa fa-check"></i> ACCOUNT CREATED</strong></h1>
								Your account was successfully created and an activation mail sent to your registered email (<?php print $_SESSION['registered']; ?>).
								<br /><br /> <form method="post"><button class="btn btn-success" name="homeBtn"><i class="fa fa-home"></i> Back Home</button> </form>
							</div>
                        </div>
						<?php } ?>
                    </div>
                </div>
            </div>
        </div>
		<!-- /Main Wrapper -->
		
		<!-- jQuery -->
        <script src="<?php print $dir; ?>login-assets/js/jquery-3.2.1.min.js"></script>
		
		<!-- Bootstrap Core JS -->
        <script src="<?php print $dir; ?>login-assets/js/popper.min.js"></script>
        <script src="<?php print $dir; ?>login-assets/js/bootstrap.min.js"></script>
		
		<!-- Custom JS -->
		<script src="<?php print $dir; ?>login-assets/js/script.js"></script>
		
    </body>
</html>