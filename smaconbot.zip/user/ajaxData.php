<?php
//Include database configuration file
include('connection.php');

if(isset($_POST["bch_val"]) && !empty($_POST["bch_val"])){
    $bchVal = $_POST['bch_val'];
	$jsnsrc = "https://api.kraken.com/0/public/Ticker?pair=BCHUSD";
	$json = file_get_contents($jsnsrc);
	$json = json_decode($json);
	$one_Btc_To_Usd = $json->result->BCHUSD->a[0];

	$curAmount = $bchVal*$one_Btc_To_Usd;
	$realAmount = explode('.', $curAmount);
	$main = $realAmount[0];
	$decimal = $realAmount[1];

	print number_format($main).'.'.$decimal;
}
?>