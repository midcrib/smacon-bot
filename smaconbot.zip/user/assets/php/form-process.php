<?php
	$dir = '../../';
	require $dir.'connection.php';
	
	$trxnHash = mysqli_real_escape_string($conn, $_POST['trxnhash']);
	$description = mysqli_real_escape_string($conn, $_POST['message']);
	$postedOn = date("d-M-Y h:i:s a");
	
	if(strlen($trxnHash) != 66){
		print 'Invalid Transaction Hash entered!';
	}
	else{
		/////check to ensure that the transaction hash is not already recorded////
		$queryTrxn = mysqli_query($conn, "SELECT * FROM tbl_trxn_hash WHERE trxn_hash='$trxnHash'");
		if(mysqli_num_rows($queryTrxn) > 0){
			$msg = '<span class="text-danger">Invoice Number already in use.</span>';
		}
		else{
			
		}
	}
?>