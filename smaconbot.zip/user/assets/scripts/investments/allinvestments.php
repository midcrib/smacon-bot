<?php
	$dir = '../../../../';
	require_once($dir.'connection.php');
	$totalInvestment = 0.000;
	$invTotal = 0;
	$queryPayments = mysqli_query($conn, "SELECT * FROM tbl_payments WHERE user_id='$smaconbotUser'");
	while($investment = mysql_fetch_assoc($queryPayments)){
		$servFee = 0.05*$investment['bch_amount'];
		$invest = $investment['bch_amount']-$servFee;
		$totalInvestment = $totalInvestment+$invest;
		$invTotal++;
	}
	
?>
<h3> Total Investment(<?php print $invTotal; ?>)</h3>
<h1><?php print $totalInvestment; ?></h1>
<h2>BCH</h2>
<p class="text-bold text-white">Total investment made on SmaconBot.</p>