<?php

$jsnsrc = "https://blockchain.info/ticker";
$json = file_get_contents($jsnsrc);
$json = json_decode($json);
$one_Btc_To_Brl = explode('.', $json->USD->last);
$symbol = $json->USD->symbol;
$main = $one_Btc_To_Brl[0];
$decimal = $one_Btc_To_Brl[1];

$btcValue =  $symbol.number_format($main).'.'.$decimal;
?>