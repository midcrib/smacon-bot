<?php
error_reporting(0);
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbName = "smaconbot";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbName);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

	$webUrl = 'https://www.anyimpiusanyim.org/';

	date_default_timezone_set('Africa/Lagos');
	
	$regNew = $_SESSION['regCodeSet'];

	$baseUrl = 'http://localhost/ebsirsapp/main-ebsirb-system/';

	function currentPageURL(){
		$PageURL = 'http';
	 if ($_SERVER["HTTPS"] == "on"){
		$PageURL .= "s";
	 }
	 
	 $PageURL .= "://";
	 if ($_SERVER["SERVER_PORT"] != "80"){
		$PageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
	 }
	 else{
		$PageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
	 }
	 return $PageURL;
	}

	$url = currentPageURL();
	
	if (!empty($_SERVER["HTTP_CLIENT_IP"])){
	 //check for ip from share internet
	 $ip = $_SERVER["HTTP_CLIENT_IP"];
	}
	elseif (!empty($_SERVER["HTTP_X_FORWARDED_FOR"])){
	 // Check for the Proxy User
	 $ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
	}
	else{
	 $ip = $_SERVER["REMOTE_ADDR"];
	}
	
	$ipAddress = $ip;
	
	//////Get user image/////
	$profileImage = 'default.png';
	
	/////logout script///
	if(!empty($_GET['logout'])){
		session_destroy();
		header("Location: $dir");
	}
?>