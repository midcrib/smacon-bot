﻿<?php	
	$title = 'Add Wallet Address | ';
	
?>
<?php include($dir.'header.php'); ?>

<script>
	$(document).ready(function(){
		setInterval(function(){
			$("#totalInvestment").load('<?php print $dir; ?>investments/allinvestments.php'),
			$("#totalPayout").load('<?php print $dir; ?>investments/payout.php'),
			$("#totalEarning").load('<?php print $dir; ?>investments/earning.php')
		}, 2000);
	});
</script>
</div>         
          <!-- PAGE CONTENT -->
          <div class="right_col" id="dashboard-v2" role="main">
            <div class="row">
              <div class="col-xs-12 col-sm-6 col-lg-4">
                <div class="panel panel-danger element-box-shadow market-place">
                  <div class="panel-heading no-padding">
                    <div class="div-market-place">
                      <h3> Market Place (USD)</h3>
                      <h1>$9,448.91</h1>
                      <h2>USD</h2>
                      <p class="text-bold text-white">Average USD market price across<br>
                          major bitcoin exchanges.</p>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-xs-12 col-sm-6 col-lg-4">
                <div class="panel panel-success element-box-shadow market-place">
                  <div class="panel-heading no-padding">
                    <div class="div-market-place">
                      <h3> Transactions pre Day </h3>
                      <h1>217,859</h1>
                      <h2>Transactions</h2>
                      <p class="text-bold text-white">The aggregate number of confirmed<br>
                          Bitcoin transactions in the past 24 hours.</p>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-xs-12 col-sm-6 col-lg-4">
                <div class="panel panel-info element-box-shadow market-place">
                  <div class="panel-heading no-padding">
                    <div class="div-market-place">
                      <h3> Mempool Size </h3>
                      <h1>49,522,895</h1>
                      <h2>Bytes</h2>
                      <p class="text-bold text-white">The aggregate size of<br>
                          transactions waiting to be confirmed.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
