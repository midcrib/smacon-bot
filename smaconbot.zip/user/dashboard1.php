<?php	
	$title = 'Add Wallet Address | ';
	
?>
<?php include($dir.'header.php'); ?>

<script>
	$(document).ready(function(){
		setInterval(function(){
			$("#totalInvestment").load('<?php print $dir; ?>investments/allinvestments.php'),
			$("#totalPayout").load('<?php print $dir; ?>investments/payout.php'),
			$("#dailyEarning").load('<?php print $dir; ?>investments/dailyearning.php'),
			$("#nextPayout").load('<?php print $dir; ?>investments/nextpayout.php'),
			$("#currentBalance").load('<?php print $dir; ?>investments/currentbalance.php'),
			$("#totalEarning").load('<?php print $dir; ?>investments/earning.php')
		}, 2000);
	});
</script>
		<div id="crypto_address" class="right_col crypto_address" role="main">
            <div class="spacer_30"></div>
            <div class="clearfix"></div>
            <div class="row">
              
            </div>
            <div class="spacer_30"></div>
            <div class="clearfix"></div>
            <div class="address-section">
              <div class="container">
                <div class="row">
                  <div class="col-xs-12 col-sm-6 col-lg-4">
					<div class="panel panel-danger element-box-shadow market-place">
						<div class="panel-heading no-padding">
							<div class="div-market-place" id="totalInvestment"></div>
						</div>  
					</div>
				  </div>
				  <div class="col-xs-12 col-sm-6 col-lg-4">
					<div class="panel panel-success element-box-shadow market-place">
					  <div class="panel-heading no-padding">
						<div class="div-market-place" id="totalEarning"></div>
					  </div>
					</div>
				  </div>
				  <div class="col-xs-12 col-sm-6 col-lg-4">
					<div class="panel panel-info element-box-shadow market-place">
					  <div class="panel-heading no-padding">
						<div class="div-market-place" id="dailyEarning"></div>
					  </div>
					</div>
				  </div>
				  <div class="col-xs-12 col-sm-6 col-lg-4">
					<div class="panel panel-warning element-box-shadow market-place">
					  <div class="panel-heading no-padding">
						<div class="div-market-place" id="nextPayout"></div>
					  </div>
					</div>
				  </div>
				  <div class="col-xs-12 col-sm-6 col-lg-4">
					<div class="panel panel-info element-box-shadow market-place">
					  <div class="panel-heading no-padding">
						<div class="div-market-place" id="totalPayout"></div>
					  </div>
					</div>
				  </div>
					<div class="col-xs-12 col-sm-6 col-lg-4">
						<div class="panel panel-primary element-box-shadow market-place">
						  <div class="panel-heading no-padding">
							<div class="div-market-place" id="currentBalance"></div>
						  </div>
						</div>
				  </div>
                </div><!-- Row -->
				
              </div><!-- container -->
            </div><!-- section1 -->
          </div>