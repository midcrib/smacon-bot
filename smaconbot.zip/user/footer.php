		  <!--<div class="buy_now">
            <a href="../item/cryptic-crypto-ui-kit/21390013.html">
              <div class="btn-hover-text"><p class="element-box-shadow text-bold">Purchase for 24$</p></div>
              <button class="button_buy_now text-bold element-box-shadow"><i class="icon-basket icons"></i>
              </button>
            </a>
            <div class="btn-small">$24</div>
          </div>-->
          <a href="#" class="scrollToTop"><i class="fa fa-chevron-up text-white" aria-hidden="true"></i></a>
          <!-- PAGE FOOTER -->
          <footer>
            <div class="pull-right">
              Copyright &copy; <?php print date("Y", time()); ?> <a href="javascript: void();"><strong>SmaconBot</strong></a>. All Rights Reserved.
            </div>
            <div class="clearfix"></div>
          </footer>
        </div>
        <!-- RIGHT SIDE SIDEBAR NAVIGATION -->
        <div class="right-side">
          <nav class="st-menu st-effect">
              <span class="fa fa-times close-sidebar" id="close-sidebar"></span>
              <table class="table table-cryptic dataTable no-footer" id="dataTable_crypto_mining_pool" role="grid">
                <thead>
                   <tr role="row">
                      <th colspan="2" rowspan="1">Currency <i class="fa fa-sort"></i></th>
                      <th class="text-right">Price <i class="fa fa-sort"></i></th>
                   </tr>
                </thead>
                 <tbody>
                    <tr role="row">
                       <td><span><a href="#"><i class="cc BTC" title="BTC"></i></a></span></td>
                       <td>
                          <h6><a href="#" class="d-none d-md-block d-lg-block d-xl-block"> Bitcoin</a></h6>
                          <small class="text-muted">BTC</small>
                       </td>
                       <td class="text-right"><p><span>$</span> 11,723.40</p></td>
                    </tr>
                    <tr role="row">
                       <td><span><a href="#"><i class="cc ETH" title="ETH"></i></a></span></td>
                       <td>
                          <h6><a href="#" class="d-none d-md-block d-lg-block d-xl-block"> Ethereum</a></h6>
                          <small class="text-muted">ETH</small>
                       </td>
                       <td class="text-right"><p><span>$</span> 1,070.39</p></td>
                    </tr>
                    <tr role="row">
                       <td><span><a href="#"><i class="cc XRP" title="XRP"></i></a></span></td>
                       <td>
                          <h6><a href="#" class="d-none d-md-block d-lg-block d-xl-block"> Ripple</a></h6>
                          <small class="text-muted">XRP</small>
                       </td>
                       <td class="text-right"><p><span>$</span> 1.64</p></td>
                    </tr>
                    <tr role="row">
                       <td><span><a href="#"><i class="cc ADA" title="ADA"></i></a></span></td>
                       <td>
                          <h6><a href="#" class="d-none d-md-block d-lg-block d-xl-block"> Cardano</a></h6>
                          <small class="text-muted">ADA</small>
                       </td>
                       <td class="text-right"><p><span>$</span> 0.68</p></td>
                    </tr>
                    <tr role="row">
                       <td><span><a href="#"><i class="cc LTC" title="LTC"></i></a></span></td>
                       <td>
                          <h6><a href="#" class="d-none d-md-block d-lg-block d-xl-block"> Litecoin</a></h6>
                          <small class="text-muted">LTC</small>
                       </td>
                       <td class="text-right"><p><span>$</span> 198.88</p></td>
                    </tr>
                    <tr role="row">
                       <td><span><a href="#"><i class="cc XEM" title="XEM"></i></a></span></td>
                       <td>
                          <h6><a href="#" class="d-none d-md-block d-lg-block d-xl-block"> NEM</a></h6>
                          <small class="text-muted">XEM</small>
                       </td>
                       <td class="text-right"><p><span>$</span> 1.11</p></td>
                    </tr>
                    <tr role="row">
                       <td><span><a href="#"><i class="cc NEO" title="NEO"></i></a></span></td>
                       <td>
                          <h6><a href="#" class="d-none d-md-block d-lg-block d-xl-block"> NEO</a></h6>
                          <small class="text-muted">NEO</small>
                       </td>
                       <td class="text-right"><p><span>$</span> 149.15</p></td>
                    </tr>
                    <tr role="row">
                       <td><span><a href="#"><i class="cc DASH" title="DASH"></i></a></span></td>
                       <td>
                          <h6><a href="#" class="d-none d-md-block d-lg-block d-xl-block"> Dash</a></h6>
                          <small class="text-muted">DASH</small>
                       </td>
                       <td class="text-right"><p><span>$</span> 865.27</p></td>
                    </tr>
                    <tr role="row">
                       <td><span><a href="#"><i class="cc EOS" title="EOS"></i></a></span></td>
                       <td>
                          <h6><a href="#" class="d-none d-md-block d-lg-block d-xl-block"> EOS</a></h6>
                          <small class="text-muted">EOS</small>
                       </td>
                       <td class="text-right"><p><span>$</span> 10.57</p></td>
                    </tr>
                    <tr role="row">
                       <td><span><a href="#"><i class="cc XMR" title="XMR"></i></a></span></td>
                       <td>
                          <h6><a href="#" class="d-none d-md-block d-lg-block d-xl-block"> Monero</a></h6>
                          <small class="text-muted">XMR</small>
                       </td>
                       <td class="text-right"><p><span>$</span> 336.11</p></td>
                    </tr>
                    <tr role="row">
                       <td><span><a href="#"><i class="cc ETC" title="ETC"></i></a></span></td>
                       <td>
                          <h6><a href="#" class="d-none d-md-block d-lg-block d-xl-block"> Ethereum Classic</a></h6>
                          <small class="text-muted">ETC</small>
                       </td>
                       <td class="text-right"><p><span>$</span> 31.35</p></td>
                    </tr>
                    <tr role="row">
                       <td><span><a href="#"><i class="cc QTUM" title="QTUM"></i></a></span></td>
                       <td>
                          <h6><a href="#" class="d-none d-md-block d-lg-block d-xl-block"> Qtum</a></h6>
                          <small class="text-muted">QTUM</small>
                       </td>
                       <td class="text-right"><p><span>$</span> 38.18</p></td>
                    </tr>
                 </tbody>
              </table>
          </nav>
        </div>
      </div>
      <!-- RIGHT SIDE: SEARCH FORM -->
      <div class="search search-main">
        <div id="btn-search-close" class="btn btn--search-close" aria-label="Close search form">
          <i class="fa fa-times"></i>
        </div>
        <form class="search__form" action="search.html">
          <input class="search__input" name="search" type="search" placeholder="Hash, transaction reference..." autocapitalize="off" spellcheck="false">
          <span class="search__info">Hit enter to search or ESC to close</span>
        </form>
      </div>
      <!-- JS SCRIPTS -->
      <script src="<?php print $dir; ?>assets/js/jquery.min.js"></script>
      <script src="<?php print $dir; ?>assets/js/jquery.scrollbar.min.js"></script>
      <script src="<?php print $dir; ?>assets/plugins/modernizr/modernizr.custom.js"></script>
      <script src="<?php print $dir; ?>assets/plugins/classie/classie.js"></script>  
      <script src="<?php print $dir; ?>assets/plugins/bootstrap/bootstrap.min.js"></script>
      <script src="<?php print $dir; ?>assets/plugins/select2/select2.min.js"></script>
      <script src="<?php print $dir; ?>assets/plugins/highcharts/highcharts.js"></script>
      <script src="<?php print $dir; ?>assets/plugins/highcharts/exporting.js"></script>
      <!-- Custom Charts Scripts -->
      <script src="<?php print $dir; ?>assets/js/charts.js"></script>
      <script src="<?php print $dir; ?>assets/plugins/amcharts/amcharts.js"></script>
      <script src="<?php print $dir; ?>assets/plugins/amcharts/depthChart/serial.js"></script>
      <script src="<?php print $dir; ?>assets/plugins/amcharts/depthChart/export.min.js"></script>
      <script src="<?php print $dir; ?>assets/plugins/amcharts/depthChart/light.js"></script>
      <script src="<?php print $dir; ?>assets/js/charts-amcharts.js"></script>
	  
      <script src="<?php print $dir; ?>assets/js/filereader.js"></script>
      <script src="<?php print $dir; ?>assets/plugins/sweetalert/sweetalert.min.js"></script>
      <script src="<?php print $dir; ?>assets/plugins/sparkline/jquery.sparkline.min.js"></script>
      <script src="<?php print $dir; ?>assets/plugins/dataTables/jquery.dataTables.min.js"></script>
      <!-- Custom Theme Scripts -->
      <script src="<?php print $dir; ?>assets/js/custom.min.js"></script>
      <script src="<?php print $dir; ?>assets/js/preloader.min.js"></script> 
	  <!--Toaster-->
	  <script src="<?php print $dir; ?>assets/plugins/toastr/toastr.min.js"></script>
	  <script src="<?php print $dir; ?>assets/plugins/calendar/moment.min.js"></script>
      <script src="<?php print $dir; ?>assets/plugins/calendar/fullcalendar.min.js"></script>
      <script src="<?php print $dir; ?>assets/plugins/calendar/jquery.qtip.js"></script>
      <!-- Custom Charts Scripts -->
      <script src="<?php print $dir; ?>assets/plugins/chartjs/Chart.bundle.js"></script>
      <script src="<?php print $dir; ?>assets/plugins/chartjs/utils.js"></script>
      <script src="<?php print $dir; ?>assets/js/charts.js"></script>

	  <script>
        $(document).ready(function(){
          $('#data-tables-markets-1').DataTable();
        });
      </script>
	  
	  <script type="text/javascript">
		  $(function() {
			const Toast = Swal.mixin({
			  toast: true,
			  position: 'top-end',
			  showConfirmButton: false,
			  timer: 3000
			});

			$('.swalDefaultSuccess').click(function() {
			  Toast.fire({
				type: 'success',
				title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
			  })
			});
			$('.swalDefaultInfo').click(function() {
			  Toast.fire({
				type: 'info',
				title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
			  })
			});
			$('.swalDefaultError').click(function() {
			  Toast.fire({
				type: 'error',
				title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
			  })
			});
			$('.swalDefaultWarning').click(function() {
			  Toast.fire({
				type: 'warning',
				title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
			  })
			});
			$('.swalDefaultQuestion').click(function() {
			  Toast.fire({
				type: 'question',
				title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
			  })
			});

			$('.toastrDefaultSuccess').click(function() {
			  toastr.success('Lorem ipsum dolor sit amet, consetetur sadipscing elitr.')
			});
			$('.toastrDefaultInfo').click(function() {
			  toastr.info('Lorem ipsum dolor sit amet, consetetur sadipscing elitr.')
			});
			$('.toastrDefaultError').click(function() {
			  toastr.error('Lorem ipsum dolor sit amet, consetetur sadipscing elitr.')
			});
			$('.toastrDefaultWarning').click(function() {
			  toastr.warning('Lorem ipsum dolor sit amet, consetetur sadipscing elitr.')
			});

			$('.toastsDefaultDefault').click(function() {
			  $(document).Toasts('create', {
				title: 'Toast Title',
				body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
			  })
			});
			$('.toastsDefaultTopLeft').click(function() {
			  $(document).Toasts('create', {
				title: 'Toast Title',
				position: 'topLeft',
				body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
			  })
			});
			$('.toastsDefaultBottomRight').click(function() {
			  $(document).Toasts('create', {
				title: 'Toast Title',
				position: 'bottomRight',
				body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
			  })
			});
			$('.toastsDefaultBottomLeft').click(function() {
			  $(document).Toasts('create', {
				title: 'Toast Title',
				position: 'bottomLeft',
				body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
			  })
			});
			$('.toastsDefaultAutohide').click(function() {
			  $(document).Toasts('create', {
				title: 'Toast Title',
				autohide: true,
				delay: 750,
				body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
			  })
			});
			$('.toastsDefaultNotFixed').click(function() {
			  $(document).Toasts('create', {
				title: 'Toast Title',
				fixed: false,
				body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
			  })
			});
			$('.toastsDefaultFull').click(function() {
			  $(document).Toasts('create', {
				body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.',
				title: 'Toast Title',
				subtitle: 'Subtitle',
				icon: 'fas fa-envelope fa-lg',
			  })
			});
			$('.toastsDefaultFullImage').click(function() {
			  $(document).Toasts('create', {
				body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.',
				title: 'Toast Title',
				subtitle: 'Subtitle',
				image: '<?php print $dir; ?>dist/img/user3-128x128.jpg',
				imageAlt: 'User Picture',
			  })
			});
			$('.toastsDefaultSuccess').click(function() {
			  $(document).Toasts('create', {
				class: 'bg-success', 
				title: 'Toast Title',
				subtitle: 'Subtitle',
				body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
			  })
			});
			$('.toastsDefaultInfo').click(function() {
			  $(document).Toasts('create', {
				class: 'bg-info', 
				title: 'Toast Title',
				subtitle: 'Subtitle',
				body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
			  })
			});
			$('.toastsDefaultWarning').click(function() {
			  $(document).Toasts('create', {
				class: 'bg-warning', 
				title: 'Toast Title',
				subtitle: 'Subtitle',
				body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
			  })
			});
			$('.toastsDefaultDanger').click(function() {
			  $(document).Toasts('create', {
				class: 'bg-danger', 
				title: 'Toast Title',
				subtitle: 'Subtitle',
				body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
			  })
			});
			$('.toastsDefaultMaroon').click(function() {
			  $(document).Toasts('create', {
				class: 'bg-maroon', 
				title: 'Toast Title',
				subtitle: 'Subtitle',
				body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
			  })
			});
		  });

		</script>
    </div>
  </body>
</html>