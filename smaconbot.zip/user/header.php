<?php
	if(!empty($_GET['logout'])){
		session_destroy();
		header("Location: $pageDir");
	}
?>

<?php if(empty($title)){ $title = 'SmaconBot - The world\'s most robust trading technology'; }else{ $title=$title; } ?>
<!DOCTYPE html>
<html lang="en">
	<head>
    <meta charset="UTF-8">
    <meta name="keywords" content="HTML,CSS,JavaScript">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="icon" href="<?php print $dir; ?>assets/images/favicon.png" type="image/ico">
		<title><?php print $title; ?> SmaconBot - The world's most robust trading technology</title>
		<!-- CSS -->
		<!-- Bootstrap -->
    <link href="<?php print $dir; ?>assets/plugins/bootstrap/bootstrap.min.css" rel="stylesheet">
    <link href="<?php print $dir; ?>assets/fonts/cryptocoins.css" rel="stylesheet">
    <link href="<?php print $dir; ?>assets/plugins/dataTables/jquery.dataTables.min.css" rel="stylesheet">
		<!-- Simple line icons -->
		<link href="<?php print $dir; ?>assets/css/simple-line-icons.css" rel="stylesheet">
    <!-- Font awesome icons -->
    <link href="<?php print $dir; ?>assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php print $dir; ?>assets/css/font-awesome-animation.min.css" rel="stylesheet">
		<!-- Custom Style -->
    <link href="<?php print $dir; ?>assets/plugins/select2/select2.min.css" rel="stylesheet">
		<link href="<?php print $dir; ?>assets/css/custom.css" rel="stylesheet">
    <link id="ui-current-skin" href="<?php print $dir; ?>assets/css/skin-colors/skin-green.css" rel="stylesheet">
    <link href="<?php print $dir; ?>assets/css/media.css" rel="stylesheet">
		
	<link href="<?php print $dir; ?>assets/plugins/calendar/fullcalendar.css" rel="stylesheet">
    <link href="<?php print $dir; ?>assets/plugins/calendar/jquery.qtip.css" rel="stylesheet">
    <!-- Charts -->
    <link href="<?php print $dir; ?>assets/plugins/rickshaw/rickshaw.min.css" rel="stylesheet">
	<!-- Toastr -->
    <link rel="stylesheet" href="<?php print $dir; ?>assets/plugins/toastr/toastr.min.css">
    <!-- Custom Font -->
    <link href="../css.css?family=Sans-serif:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
	<script src="<?php print $dir; ?>jquery.min.js"></script>
  	<script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
	
	</head>
  <body class="nav-md preloader-off developer-mode">
	 <script type="text/javascript">
		$(document).ready(function(){
			$('#bchValue').on('change',function(){
				var bchVal = $(this).val();
				if(bchVal){
					$.ajax({
						type:'POST',
						url:'<?php print $dir; ?>ajaxData.php',
						data:'bch_val='+minID,
						success:function(html){
							$('#usdValue').html(html);
						}
					}); 
				}else{
					$('#usdValue').html('0.00');
				}
			});
		});
	</script> 
	  
    <div class="pace-cover"></div>
    <div id="st-container" class="st-container st-effect">
      <!-- MAIN PAGE CONTAINER -->
      <div class="container body">
        <div class="main_container">
          <!-- LEFT PRIMARY NAVIGATION -->
          <div class="col-md-3 left_col">
            <div class="scroll-view">
              <div class="clearfix">
                <div class="navbar nav_title">
                  <h1 class="logo_wrapper"> <a href="<?php print $dir; ?>" class="site_logo"> <img class="logo" src="<?php print $dir; ?>assets/images/logo.png" alt="SmaconBot logo">
                    <!--<span class="logo-text">SmaconBot</span>-->
                  </a></h1>
                </div>
              </div>
              <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
                <div class="menu_section">
                  <h3>Main Menu</h3>
                  <div class="clearfix"></div>
                  <ul class="nav side-menu" disabled>
                    <li><a href="<?php print $pageDir; ?>"><i class="fa fa-home icons"></i><span> Home Page</span></a></li>
					<li><a href="<?php print $dir; ?>"><i class="fa fa-tachometer icons"></i><span> My Dashboard</span></a></li>
                    
                    <li><a><i class="icon-chart icons"></i> <span>History </span><span class="fa fa-angle-down"></span></a>
                      <ul class="nav child_menu">
                        <li><a href="<?php print $dir; ?>history/?rel=deposit"><span>Deposit History</span></a></li>
                        <li><a href="<?php print $dir; ?>history/?rel=withdrawal"><span>Withdrawal History</span></a></li>
                        <li><a href="<?php print $dir; ?>history/?rel=bonuses"><span>Bonuses</span></a></li>
                      </ul>
                    </li>
                    <li><a><i class="fa fa-money icons"></i> <span>Transactions <span class="fa fa-angle-down"></span></span></a>
                      <ul class="nav child_menu">
                        <li><a href="<?php print $dir; ?>transactions/deposit"><span>Fund Deposit</span></a></li>
                        <li><a href="<?php print $dir; ?>transactions/withdrawal"><span>Fund Withdrawal</span></a></li>
                      </ul>
                    </li>
                    <li><a href="<?php print $dir; ?>referrals"><i class="fa fa-users icons"></i> <span>Referrals</span></a></li>
                  </ul>
                </div>
              </div>
              <!-- /sidebar menu -->
              <!-- /menu footer buttons -->
              <div class="sidebar-footer hidden-small">
                <a data-toggle="tooltip" data-placement="top" title="Settings">
                  <span class="icon-settings icons" aria-hidden="true"></span>
                </a>
                <a data-toggle="tooltip" id="btnFullscreen" data-placement="top" title="FullScreen">
                  <span class="icon-size-fullscreen icons" aria-hidden="true"></span>
                </a>
                <a data-toggle="tooltip" data-placement="top" title="Lock">
                  <span class="icon-eye icons" aria-hidden="true"></span>
                </a>
                <a data-toggle="tooltip" data-placement="top" title="Logout" href="javascript: void();" onClick="location.href='<?php print $dir; ?>?logout=<?php print $_SESSION['smaconbot_user']; ?>';">
                  <span class="icon-power icons" aria-hidden="true"></span>
                </a>
              </div>
              <!-- /menu footer buttons -->
            </div>
          </div>
          <!-- TOP SECONDARY NAVIGATION -->
          <div class="top_nav">
            <div class="nav_menu">
              <ul class="nav navbar-nav navbar-left new-navbar-right">
                <li class="toggle-li">
                  <div class="nav toggle burger-nav">
                    <a id="menu_toggle">
                      <div class="burger">
                        <span></span>
                        <span></span>
                        <span></span>
                      </div>
                    </a>
                  </div>
                </li>
              </ul>
              <ul class="nav navbar-nav navbar-left">
                <li class="megamenu-li">                  
                  <!-- megamenu -->
                  <div class="megamenu-dropdown-wrapper">
                    <a class="megamenu-dropdown-trigger megamenu-trigger" href="#0">
                      <i class="icon-wallet icons"></i>
                      <span> My Wallet </span>
                      <span class="fa fa-angle-down"></span>
                    </a>
                    <nav class="megamenu-dropdown">
                      <a href="#0" class="megamenu-close">Close</a>
                      <ul class="megamenu-dropdown-content">
                        <li>
                          <a href="<?php print $dir; ?>wallet/investment"><i class="cc mmt-icon BCH" title="BTC"></i> Investments (<i class="fa fa-bch"></i>)</a>
                        </li>
						<li>
                          <a href="<?php print $dir; ?>wallet/interest"><i class="icon-wallet icons cc"></i> Interest</a>
                        </li>
						<li>
                          <a href="<?php print $dir; ?>wallet/growth"><i class="icon-wallet icons cc"></i> Current Growth</a>
                        </li>
						<li>
                          <a href="<?php print $dir; ?>wallet/new-investment"><i class="icon-wallet icons cc"></i> Add New Investment</a>
                        </li>
						  <!-- .has-children -->
                        <!--<li class="has-children">
                          <a href="#"><i class="cc mmt-icon LTC" title="LTC"></i> Litecoin</a>
                          <ul class="megamenu-dropdown-icons is-hidden">
                            <li>
                              <a class="megamenu-dropdown-item item-1" href="search.html">
                                <h3><i class="cc mmt-icon LTC" title="LTC"></i> All Transactions (LTC)</h3>
                                <div>View Sent/Received Transactions</div>
                              </a>
                            </li>
                            <li>
                              <a class="megamenu-dropdown-item item-2" href="search.html">
                                <h3><i class="cc mmt-icon LTC" title="LTC"></i> Sent LTC (Transactions)</h3>
                                <div>In-dept Check Sent Transactions</div>
                              </a>
                            </li>
                            <li>
                              <a class="megamenu-dropdown-item item-3" href="search.html">
                                <h3><i class="cc mmt-icon LTC" title="LTC"></i> Received LTC (Transactions)</h3>
                                <div>In-dept Check Received Transactions</div>
                              </a>
                            </li>
                            <li>
                              <a class="megamenu-dropdown-item item-4" href="search.html">
                                <h3><i class="cc mmt-icon LTC" title="LTC"></i> Exchanged LTC (Transactions)</h3>
                                <div>View Sent/Received Exchanges</div>
                              </a>
                            </li>
                          </ul> <!-- .megamenu-dropdown-icons ->
                        </li> <!-- .has-children ->
                        <li class="has-children">
                          <a href="#"><i class="cc mmt-icon ETH" title="ETH"></i> Ethereum</a>
                          <ul class="megamenu-dropdown-icons is-hidden">
                            <li>
                              <a class="megamenu-dropdown-item item-1" href="search.html">
                                <h3><i class="cc mmt-icon ETH" title="ETH"></i> All Transactions (ETH)</h3>
                                <div>View Sent/Received Transactions</div>
                              </a>
                            </li>
                            <li>
                              <a class="megamenu-dropdown-item item-2" href="search.html">
                                <h3><i class="cc mmt-icon ETH" title="ETH"></i> Sent ETH (Transactions)</h3>
                                <div>In-dept Check Sent Transactions</div>
                              </a>
                            </li>
                            <li>
                              <a class="megamenu-dropdown-item item-3" href="search.html">
                                <h3><i class="cc mmt-icon ETH" title="ETH"></i> Received ETH (Transactions)</h3>
                                <div>In-dept Check Received Transactions</div>
                              </a>
                            </li>
                            <li>
                              <a class="megamenu-dropdown-item item-4" href="search.html">
                                <h3><i class="cc mmt-icon ETH" title="ETH"></i> Exchanged ETH (Transactions)</h3>
                                <div>View Sent/Received Exchanges</div>
                              </a>
                            </li>
                          </ul> <!-- .megamenu-dropdown-icons ->
                        </li> <!-- .has-children ->
                        <li class="has-children">
                          <a href="#"><i class="cc mmt-icon DASH" title="DASH"></i> DASH</a>
                          <ul class="megamenu-dropdown-icons is-hidden">
                            <li>
                              <a class="megamenu-dropdown-item item-1" href="search.html">
                                <h3><i class="cc mmt-icon DASH" title="DASH"></i> All Transactions (DASH)</h3>
                                <div>View Sent/Received Transactions</div>
                              </a>
                            </li>
                            <li>
                              <a class="megamenu-dropdown-item item-2" href="search.html">
                                <h3><i class="cc mmt-icon DASH" title="DASH"></i> Sent DASH (Transactions)</h3>
                                <div>In-dept Check Sent Transactions</div>
                              </a>
                            </li>
                            <li>
                              <a class="megamenu-dropdown-item item-3" href="search.html">
                                <h3><i class="cc mmt-icon DASH" title="DASH"></i> Received DASH (Transactions)</h3>
                                <div>In-dept Check Received Transactions</div>
                              </a>
                            </li>
                            <li>
                              <a class="megamenu-dropdown-item item-4" href="search.html">
                                <h3><i class="cc mmt-icon DASH" title="DASH"></i> Exchanged DASH (Transactions)</h3>
                                <div>View Sent/Received Exchanges</div>
                              </a>
                            </li>
                          </ul> <! .megamenu-dropdown-icons ->
                        </li> <!- .has-children -->
                      </ul> <!-- .megamenu-dropdown-content -->
                    </nav> <!-- .megamenu-dropdown -->
                  </div> <!-- .megamenu-dropdown-wrapper -->
                  <!-- megamenu -->              
                </li>
                <li class="dropdown-menu-1-li">
                  <div class="dropdown-menu-1 dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown"><i class="icon-feed icons"></i> Reports
                    <span class="fa fa-angle-down"></span></a>
                    <ul class="dropdown-menu archive">
                      <li><a href="crypto_address.html"><span class="pull-left">All Withdrawals()</span></a></li>
                      <li><a href="crypto_address.html"><span class="pull-left">All Payments()</span></a></li>
                      <li><a href="crypto_address.html"><span class="pull-left">All Transfers</span> </a></li>
                    </ul>
                  </div>
                </li>
                <!--<li class="button-night-mode">Night Mode
                  <button type="button" class="btn btn-sm btn-toggle" data-toggle="button" aria-pressed="true" autocomplete="off">
                    <div class="handle"></div>
                  </button>
                </li>-->
                <li class="button-menu-right">Menu Right
                  <button type="button" class="btn btn-sm btn-toggle" data-toggle="button" aria-pressed="true" autocomplete="off">
                    <div class="handle"></div>
                  </button>
                </li>
              </ul> <!-- top menu ul -->
              <ul class="nav navbar-nav navbar-right">
                <!--<li id="st-trigger-effects" class="">
                  <a data-effect="st-effect" class="trigger-sidebar">
                    <i class="fa fa-th"></i>
                  </a>
                </li>-->
                <li class="">
                  <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    <img src="<?php print $dir; ?>assets/images/users/<?php print $profileImage; ?>" alt="">
                  </a>
                  <ul class="dropdown-menu dropdown-usermenu pull-right">
                    <li><a href="javascript:;"> My Profile</a></li>
                    <li>
                      <a href="javascript:;">
                        <span class="badge bg-red pull-right">50%</span>
                        <span>Settings</span>
                      </a>
                    </li>
                    <li><a href="javascript:;">Help</a></li>
                    <li><a href="<?php print $dir; ?>?logout=<?php print $_SESSION['smaconbot_user']; ?>"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
                  </ul>
                </li>
                <!--<li role="presentation" class="dropdown">
                  <a href="javascript:;" class="dropdown-toggle info-number faa-horizontal" data-toggle="dropdown" aria-expanded="false">
                    <i class="fa fa-envelope faa-horizontal animated"></i>
                    <span class="badge faa-horizontal animated">3</span>
                  </a>
                  <ul id="menu1" class="dropdown-menu list-unstyled msg_list" role="menu">
                    <li>
                      <a>
                        <span class="image"><img src="assets/images/profile-pic.jpg" alt="Profile Image"></span>
                        <span>
                          <span>John Smith</span>
                          <span class="time">3 mins ago</span>
                        </span>
                        <span class="message">
                          Film festivals used to be do-or-die moments for movie makers...
                        </span>
                      </a>
                    </li>
                    <li>
                      <a>
                        <span class="image"><img src="assets/images/profile-pic.jpg" alt="Profile Image"></span>
                        <span>
                          <span>John Smith</span>
                          <span class="time">4 mins ago</span>
                        </span>
                        <span class="message">
                          Film festivals used to be do-or-die moments for movie makers...
                        </span>
                      </a>
                    </li>
                    <li>
                      <a>
                        <span class="image"><img src="assets/images/profile-pic.jpg" alt="Profile Image"></span>
                        <span>
                          <span>John Smith</span>
                          <span class="time">6 mins ago</span>
                        </span>
                        <span class="message">
                          Film festivals used to be do-or-die moments for movie makers...
                        </span>
                      </a>
                    </li>
                    <li>
                      <div class="text-center">
                        <a>
                          <strong>See All Alerts</strong>
                          <i class="fa fa-angle-right"></i>
                        </a>
                      </div>
                    </li>
                  </ul>
                </li>-->
                <li class="search-wrap">
                  <a href="javascript:;" id="btn-search" class="search-nav">
                    <i class="fa fa-search" aria-hidden="true"></i>
                  </a>
                </li>
                <li class="language">
                  <a href="javascript:;" class="lang-swich dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    <img src="<?php print $dir; ?>assets/images/united-kingdom.svg" alt="uk">
                  </a>
                  <!--<ul class="dropdown-menu dropdown-usermenu pull-right">
                    <li><a href="javascript:;"><img src="assets/images/france.svg" alt="fr"><span>France</span></a></li>
                    <li><a href="javascript:;"><img src="assets/images/germany.svg" alt="de"><span>Germany</span></a></li>
                    <li><a href="javascript:;"><img src="assets/images/italy.svg" alt="it"><span>Italy</span></a></li>
                    <li><a href="javascript:;"><img src="assets/images/spain.svg" alt="es"><span>Spain</span></a></li>
                  </ul>-->
                </li>
              </ul>
            </div>
          </div>