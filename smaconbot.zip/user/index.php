﻿<?php
	$dir = './';
	$pageDir = '../';
	require_once($pageDir.'connection.php');

	if(empty($_SESSION['smaconbot_user'])){
		header("Location: $pageDir"."login");
	}
?>
<?php 
   if(mysqli_num_rows($queryPayments) < 1){
	   include($dir.'initial-reg.php');
   }else{
	   if(mysqli_num_rows($queryUserAddr) < 1){
		  include($dir.'wallet-add.php'); 
	   }
	   else{
		   ////print the dashboard here///////
		   include($dir.'dashboard1.php');
	   }
   }
	
?>
		  
 <?php include($dir.'footer.php'); ?>