<?php
	
$bchAddress = 'qqsqhhg6jrhcylldtg4h978x7vshdvy5dsqqvr796z';
	$title = 'Plan Selection | ';
	$userId = $smaconbotUser;
	//////////SUBMIT SELECTED PLAN//////
	if(isset($_POST['submitPlan'])){
		$_SESSION['submitted'] = 'true';
		header("refresh: 3; url=./");
	}
	
	if(!empty($_SESSION['submitted'])){
		$_SESSION['plan_selected'] = $_POST['plan'];
		$_SESSION['plan'] = $_POST['plan'];
		$_SESSION['plan_amount'] = $_POST['amount'];
		unset($_SESSION['submitted']);
		header("Locatioon: $dir");
	}
	
	////////change selected plan//////////
	if(isset($_POST['changePlan'])){
		unset($_SESSION['plan_selected']);
		unset($_SESSION['plan_amount']);
		header("Location: ./");
	}
	
	if(isset($_POST['makePayment'])){
		$bchValue = $_POST['bch-value'];
		//////generate the QR code for the Payment///////
		$PNG_TEMP_DIR = $dir.'transactions-hash'.DIRECTORY_SEPARATOR;

		include $dir."QR/qrlib.php";    
		
		//ofcourse we need rights to create temp dir
		if (!file_exists($PNG_TEMP_DIR))
		mkdir($PNG_TEMP_DIR);
		$pmtRef = md5(time().rand(100000, 999999).time());
		$_SESSION['transaction_id'] = $pmtRef;
		$_SESSION['bch_address'] = $bchAddress;
		$_SESSION['plan-value'] = $bchValue;
		$addressDetails = 'bitcoincash:qqsqhhg6jrhcylldtg4h978x7vshdvy5dsqqvr796z?amount='.$_SESSION['plan-value'];
		$matrixPointSize = 6;
		$errorCorrectionLevel = 'L';
		$filename = $PNG_TEMP_DIR.$pmtRef.'.png';
		QRcode::png($addressDetails, $filename, $errorCorrectionLevel, $matrixPointSize, 2); 
		
		$_SESSION['final-payment'] = rand(1000000,9999999);
		header("Location: $dir");
	}
	
	if(isset($_POST['submitTrxn'])){
		$trxn = mysqli_real_escape_string($conn, $_POST['traxn_hash']);
		$description = mysqli_real_escape_string($conn, $_POST['description']);
		$postedOn = date("d-M-Y h:i:s a");
		$trxLen = strlen($trxn);
		
		$plan = $_SESSION['plan'];
		$amountPaid = $_SESSION['plan-value'];
		$jsnsrc = "https://api.kraken.com/0/public/Ticker?pair=BCHUSD";
		$json = file_get_contents($jsnsrc);
		$json = json_decode($json);
		$one_Btc_To_Usd = $json->result->BCHUSD->a[0];
		
		$curAmount = $_SESSION['plan-amount']*$one_Btc_To_Usd;
		$realAmount = explode('.', $curAmount);
		$main = $realAmount[0];
		$decimal = $realAmount[1];
		$btcValue =  number_format($main).'.'.$decimal;
		
		$traxnRef = md5(time().$postedOn.time());
		
		$complete = mysqli_query($conn, "INSERT INTO tbl_payments(plan,bch_amount,usd_amount,wallet_to,user_id,received_on,traxn_reference)
			VALUES('$plan', $amountPaid, $btcValue, '$bchAddress', '$userId', '$postedOn', '$traxnRef')");
		if($complete === true){
			if($trxLen != 64){
				$msg = '<h3 class="text-danger text-center"><i class="fa fa-times"></i> Invalid Transaction Hash entered!</h3>';
			}
			else{
				/////check to ensure that the transaction hash is not already recorded////
				$queryTrxn = mysqli_query($conn, "SELECT * FROM tbl_trxn_hash WHERE trxn_hash='$trxn'");
				if(mysqli_num_rows($queryTrxn) > 0){
					$msg = '<h3 class="text-danger text-center"><i class="fa fa-times"></i> Transaction Hash already submitted.</h3>';
				}
				else{
					/////Insert the transaction/////////////
					$insertQuery = mysqli_query($conn, "INSERT INTO tbl_trxn_hash(trxn_hash, description, submitted, user_id) VALUES('$trxn', '$description', '$postedOn', '$smaconbotUser')");
					if($insertQuery === true){
						//////insert the plan to the plan table///////
						$msg = '<h3 class="text-success text-center"><i class="fa fa-times"></i> Transaction Submitted. Please, wait...<i class="fa fa-spinner fa-spin"></i></h3>';
						$_SESSION['final-submission'] = 'true';
						header("refresh: 3; url=./");
					}
					else{
						$msg = '<h3 class="text-danger text-center"><i class="fa fa-times"></i> Could not submit Hash. ('.mysqli_error($conn).')('.$trxn.')</h3>';
					}
				}
			}
		}
		else{
			$msg = '<h3 class="text-danger text-center"><i class="fa fa-times"></i> Could not submit Transaction now. ('.mysqli_error($conn).')('.$trxn.')</h3>';
		}
		
		
	}

	if(isset($_POST['cancelPayment'])){
		unlink($dir.'transactions-hash/'.$_SESSION['transaction_id'].'.png');
		unset($_SESSION['transaction_id']);
		unset($_SESSION['transaction_id']);
		unset($_SESSION['plan_selected']);
		unset($_SESSION['plan_amount']);
		unset($_SESSION['submitted']);
		unset($_SESSION['final-payment']);
		header("Location: ./");
	}
	
	if(!empty($_SESSION['final-submission'])){
		unset($_SESSION['plan_selected']);
		unset($_SESSION['final-payment']);
		unset($_SESSION['final-submission']);
		header("Location: ./");
	}
?>
<?php include($dir.'header.php'); ?>  
		
          <!-- PAGE CONTENT -->
		  <!-- PAGE CONTENT -->
		<?php if(empty($_SESSION['plan_selected']) AND !isset($_POST['submitPlan'])){ ?>
          <div class="right_col pricing-tables" role="main">
            <div class="spacer_30"></div>
            <div class="spacer_80"></div>
            <section class="pricing-section bg-12">
              <div class="pricing pricing--palden">
                  <div class="pricing__item" data-background="https://d3csh9hc31wsnz.cloudfront.net/166a3ddb-c3bf-43c8-ab59-2ab149c300b5/front/images/bg/bg-4.gif">
                      <div class="pricing__deco">
                          <svg class="pricing__deco-img" version="1.1" id="Layer_1" preserveaspectratio="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="300px" height="100px" viewbox="0 0 300 100" enable-background="new 0 0 300 100" xml:space="preserve">
                              <path class="deco-layer deco-layer--1" opacity="0.6" fill="#FFFFFF" d="M30.913,43.944c0,0,42.911-34.464,87.51-14.191c77.31,35.14,113.304-1.952,146.638-4.729
    c48.654-4.056,69.94,16.218,69.94,16.218v54.396H30.913V43.944z"></path>
                              <path class="deco-layer deco-layer--2" opacity="0.6" fill="#FFFFFF" d="M-35.667,44.628c0,0,42.91-34.463,87.51-14.191c77.31,35.141,113.304-1.952,146.639-4.729
    c48.653-4.055,69.939,16.218,69.939,16.218v54.396H-35.667V44.628z"></path>
                              <path class="deco-layer deco-layer--3" opacity="0.7" fill="#FFFFFF" d="M43.415,98.342c0,0,48.283-68.927,109.133-68.927c65.886,0,97.983,67.914,97.983,67.914v3.716
    H42.401L43.415,98.342z"></path>
                              <path class="deco-layer deco-layer--4" fill="#FFFFFF" d="M-34.667,62.998c0,0,56-45.667,120.316-27.839C167.484,57.842,197,41.332,232.286,30.428
    c53.07-16.399,104.047,36.903,104.047,36.903l1.333,36.667l-372-2.954L-34.667,62.998z"></path>
                          </svg>
                          <div class="pricing__price">0.10<span class="pricing__currency">BCH</span></div>
                          <h3 class="pricing__title text-bold">Basic Plan</h3>
                      </div>
                      <ul class="pricing__feature-list">
                          <li class="pricing__feature text-bold">BENEFITS</li>
                          <li class="pricing__feature">2.7% TO 5% PER DAY EARNING<br><span>FOR 2 MONTHS</span></li>
                          <li class="pricing__feature">TOTAL 40% + <label class="label label-success">CAPITAL</label></li>
                      </ul>
                      <form method="post">
						<input type="hidden" name="plan" value="basic" />
						<input type="hidden" name="amount" value="0.10" />
						<button name="submitPlan" class="pricing__action">Select plan</button>
					  </form>
                  </div>
                  <div class="pricing__item pricing__item--featured">
                      <div class="pricing__deco">
                          <svg class="pricing__deco-img" version="1.1" id="Layer_2" preserveaspectratio="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="300px" height="100px" viewbox="0 0 300 100" enable-background="new 0 0 300 100" xml:space="preserve">
                              <path class="deco-layer deco-layer--1" opacity="0.6" fill="#FFFFFF" d="M30.913,43.944c0,0,42.911-34.464,87.51-14.191c77.31,35.14,113.304-1.952,146.638-4.729
    c48.654-4.056,69.94,16.218,69.94,16.218v54.396H30.913V43.944z"></path>
                              <path class="deco-layer deco-layer--2" opacity="0.6" fill="#FFFFFF" d="M-35.667,44.628c0,0,42.91-34.463,87.51-14.191c77.31,35.141,113.304-1.952,146.639-4.729
    c48.653-4.055,69.939,16.218,69.939,16.218v54.396H-35.667V44.628z"></path>
                              <path class="deco-layer deco-layer--3" opacity="0.7" fill="#FFFFFF" d="M43.415,98.342c0,0,48.283-68.927,109.133-68.927c65.886,0,97.983,67.914,97.983,67.914v3.716
    H42.401L43.415,98.342z"></path>
                              <path class="deco-layer deco-layer--4" fill="#FFFFFF" d="M-34.667,62.998c0,0,56-45.667,120.316-27.839C167.484,57.842,197,41.332,232.286,30.428
    c53.07-16.399,104.047,36.903,104.047,36.903l1.333,36.667l-372-2.954L-34.667,62.998z"></path>
                          </svg>
                          <div class="pricing__price">0.20<span class="pricing__currency">BCH</span></div>
                          <h3 class="pricing__title text-bold">Standard Plan</h3>
                      </div>
                      <ul class="pricing__feature-list">
                          <li class="pricing__feature text-bold">BENEFITS</li>
                          <li class="pricing__feature">2.7% TO 5% PER DAY EARNING<br><span>FOR 2 MONTHS</span></li>
                          <li class="pricing__feature">TOTAL 40% + <label class="label label-success">CAPITAL</label></li>
                      </ul>
                      <form method="post">
						<input type="hidden" name="plan" value="standard" />
						<input type="hidden" name="amount" value="0.20" />
						<button name="submitPlan" class="pricing__action">Select plan</button>
					  </form>
                  </div>
                  <div class="pricing__item">
                      <div class="pricing__deco">
                          <svg class="pricing__deco-img" version="1.1" id="Layer_3" preserveaspectratio="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="300px" height="100px" viewbox="0 0 300 100" enable-background="new 0 0 300 100" xml:space="preserve">
                              <path class="deco-layer deco-layer--1" opacity="0.6" fill="#FFFFFF" d="M30.913,43.944c0,0,42.911-34.464,87.51-14.191c77.31,35.14,113.304-1.952,146.638-4.729
    c48.654-4.056,69.94,16.218,69.94,16.218v54.396H30.913V43.944z"></path>
                              <path class="deco-layer deco-layer--2" opacity="0.6" fill="#FFFFFF" d="M-35.667,44.628c0,0,42.91-34.463,87.51-14.191c77.31,35.141,113.304-1.952,146.639-4.729
    c48.653-4.055,69.939,16.218,69.939,16.218v54.396H-35.667V44.628z"></path>
                              <path class="deco-layer deco-layer--3" opacity="0.7" fill="#FFFFFF" d="M43.415,98.342c0,0,48.283-68.927,109.133-68.927c65.886,0,97.983,67.914,97.983,67.914v3.716
    H42.401L43.415,98.342z"></path>
                              <path class="deco-layer deco-layer--4" fill="#FFFFFF" d="M-34.667,62.998c0,0,56-45.667,120.316-27.839C167.484,57.842,197,41.332,232.286,30.428
    c53.07-16.399,104.047,36.903,104.047,36.903l1.333,36.667l-372-2.954L-34.667,62.998z"></path>
                          </svg>
                          <div class="pricing__price"><span class="pricing__period">Above</span> 0.20<span class="pricing__currency">BCH</span></div>
                          <h3 class="pricing__title text-bold">Premium Plan</h3>
                      </div>
                      <ul class="pricing__feature-list">
                          <li class="pricing__feature text-bold">BENEFITS</li>
                          <li class="pricing__feature">2.7% TO 5% PER DAY EARNING<br><span>FOR 2 MONTHS</span></li>
                          <li class="pricing__feature">TOTAL 40% + <label class="label label-success">CAPITAL</label></li>
                      </ul>
					  <form method="post">
						<input type="hidden" name="plan" value="premium" />
						<input type="hidden" name="amount" value="0.21" />
						<button name="submitPlan" class="pricing__action">Select plan</button>
					  </form>
                  </div>
              </div>
            </section>
          </div>
		<?php } ?> 
		 
		<?php if(!empty($_SESSION['submitted'])){ ?>
          <div class="right_col right_col_exchange" role="main">
            <div class="exchange-section data_background text-center">
              <h1><strong><i class="fa fa-spinner fa-spin"></i></strong></h1>
				<h1 class="text-center">Please, wait while we update your selection.</h1>
              </div>
            </div>
          </div>
		<?php } ?>
		<?php if(!empty($_SESSION['plan_selected']) AND empty($_SESSION['final-payment'])){ ?>
		<?php
			if($_SESSION['plan_selected'] == 'basic'){
				$planName = 'Basic Plan';
				$planAmount = $_SESSION['plan_amount'];
				$status = 'readonly';
			}
			elseif($_SESSION['plan_selected'] == 'standard'){
				$planName = 'Standard Plan';
				$planAmount = $_SESSION['plan_amount'];
				$status = 'readonly';
			}
			else{
				$planName = 'Premium Plan';
				$planAmount = $_SESSION['plan_amount'];
				$status = 'min="0.21"';
			}
			
			$jsnsrc = "https://api.kraken.com/0/public/Ticker?pair=BCHUSD";
			$json = file_get_contents($jsnsrc);
			$json = json_decode($json);
			$one_Btc_To_Usd = $json->result->BCHUSD->a[0];
			
			$curAmount = $_SESSION['plan_amount']*$one_Btc_To_Usd;
			$realAmount = explode('.', $curAmount);
			$main = $realAmount[0];
			$decimal = $realAmount[1];

			$btcValue =  $symbol.number_format($main).'.'.$decimal;
			
		?>
		  <div class="right_col right_col_exchange" role="main">
            <div class="exchange-section data_background text-center">
              <h1 class="text-center"><strong><?php print $planName; ?></strong></h1>
              <p class="text-center">Please, ensure that the selected plan matches the stipulated amount.</p>
              <form method="post">
				  <div class="exchange-calculator text-center">
					<input type="number" name="bch-value" id="bchValue" step="0.01" <?php print $status; ?> placeholder="" value="<?php print $planAmount; ?>">
					<select class="coins-exchange" name="currency">
					  <option value="bch">BCH</option>
					</select>
					<div class="equal"> = </div>
					<input type="text" name="currency-value" id="usdValue" placeholder="" value="<?php print $symbol.' '.number_format($main).'.'.$decimal; ?>">
					<select class="coins-exchange" name="currency">
					  <option value="bch">USD</option>
					</select>
				  </div>
				  <button name="makePayment" class="btn btn-default button-element">PROCEED TO PAYMENT</button> <button name="changePlan" class="btn btn-default button-element">Change plan</button>
			  </form>
			</div>
            <div class="clearfix"></div>
            <div class="spacer_30"></div>
            <div class="spacer_30"></div>
            <div class="spacer_30"></div>
          </div>
		<?php } ?>
		
		<?php if(!empty($_SESSION['final-payment'])){ ?>
		<?php
			$jsnsrc = "https://api.kraken.com/0/public/Ticker?pair=BCHUSD";
			$json = file_get_contents($jsnsrc);
			$json = json_decode($json);
			$one_Btc_To_Usd = $json->result->BCHUSD->a[0];
			
			$curAmount = $_SESSION['plan-value']*$one_Btc_To_Usd;
			$realAmount = explode('.', $curAmount);
			$main = $realAmount[0];
			$decimal = $realAmount[1];

			$btcValue =  '<i class="fa fa-usd"></i>'.number_format($main).'.'.$decimal;
		?>
		<div id="crypto_address" class="right_col crypto_address" role="main">
            <div class="spacer_30"></div>
            <div class="clearfix"></div>
            <div class="header-title-breadcrumb element-box-shadow">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12 text-left">
                          <h3>Bitcoin Cash (BCH) Address</h3>
						  <?php print $msg; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="spacer_30"></div>
            <div class="clearfix"></div>
            <div class="address-section">
              <div class="container">
                <div class="row">
                  <div class="col-md-8 col-lg-8">
                    <div class="table-overflow">
                    <div class="panel panel-default table-crypto_address overflow-table">
                      <div class="panel-heading padding_30">
                        <h3 class="no-margin">Payment Details</h3>
                      </div>
                      <div class="panel-body">
                        <table class="table table-striped table-hover no-margin">
                          <tbody>
							<script>
								function myFunction() {
								  var copyText = document.getElementById("walletId");
								  copyText.select();
								  copyText.setSelectionRange(0, 99999)
								  document.execCommand("copy");
								  //toastr.success('Address Copied: <strong>'+ copyText.value+'</strong>');
								  toastr.success('Address Copied');
								  document.getElementById('copyWalletBtn').innerHTML = "<i class='fa fa-check'></i> Copied</strong>";
								}
							</script>
                            <tr>
                              <td>BCH Address</td>
                              <td>
								<input type="text" class="form-control col-md-8" value="<?php print $bchAddress; ?>" id="walletId" readonly>
							  </td>
							  <td>
								<button type="button" onclick="myFunction();" id="copyWalletBtn" class="btn btn-info btn-flat">Copy Address <i class="fa fa-copy"></i></button>
							  </td>
                            </tr>
                            <tr>
                              <td>Amount</td>
                              <td><h3><strong><?php print $_SESSION['plan-value']; ?></strong><span class="text-success"> BCH</span> = <?php print $btcValue; ?></h3></td>
                            </tr>
                            <tr class="text-danger">
                              <td>Info:</td>
                              <td>Kindly make transfer of the stipulated amount or scan the QR code to proceed. After the payment is completed, click the button below to proceed.</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                  </div>
                  <div class="col-md-4 col-lg-4 text-center">
                    <div class="panel panel-default table-crypto_address overflow-table">
                      <div class="panel-heading padding_30">
                        <img src="<?php print $dir; ?>transactions-hash/<?php print $_SESSION['transaction_id'].'.png'; ?><?php //print $_SESSION['transaction_id'].'.png'; ?>" alt="codeQR">
                      </div>
                    </div>
                  </div>
				  <div class="col-md-12 col-lg-12 text-center">
                    <form method="post">
						<button type="button" name="makePayment" data-toggle="modal" data-target="#wallet-transfer" class="btn btn-default button-element"><i class="fa fa-check"></i> Confirm Payment</button> 
						<button name="cancelPayment" class="btn btn-danger button-element"><i class="fa fa-times"></i> Cancel Payment</button>
					</form>
                  </div>
                </div><!-- Row -->
				
				<div class="modal fade" id="wallet-transfer">
					<div class="modal-dialog modal-md bg-info">
					  <div class="modal-content">
						<div class="modal-header">
						  <h4 class="modal-title"><strong>Confirm Payment</strong></h4>
						  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						  </button>
						</div>
						
						<form id="contactForm" method="post">
							<div class="modal-body">
								<div class="row">
								  <div class="col-md-12">
									<div class="form-group">
										<label>Transaction Hash</label>
										<input type="text" placeholder="Enter transaction hash" value="<?php print $_POST['traxn_hash']; ?>" required name="traxn_hash" class="form-control"/> 
										<span id="error-trxn" class="text-danger"></span>
									</div>
								  </div>
								  <div class="col-md-12">
									<div class="form-group">
										<label>Description</label>
										<textarea name="description" id="message" class="form-control" value="<?php print $_POST['description']; ?>" rows="5" placeholder="Enter description"></textarea>
										<span id="error-message" class="text-danger"></span>
									</div>
								  </div>
								</div>
								<span id="errorMsg" class="text-danger"></span>
								<span id="sum" class="text-success"></span>
								<input type="hidden" name="commission" id="comVal" />
							</div>
							<div class="modal-footer justify-content-between">
							  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
							  <button type="submit" class="btn btn-primary" id="submitButton" name="submitTrxn">SUBMIT</button>
							</div>
						</form>
					  </div>
					  <!-- /.modal-content -->
					</div>
					<!-- /.modal-dialog -->
				</div>
				
              </div><!-- container -->
            </div><!-- section1 -->
          </div>
		<?php } ?>