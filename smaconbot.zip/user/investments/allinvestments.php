<?php
	$dir = '../../';
	require_once($dir.'connection.php');
	$queryPay = mysqli_query($conn, "SELECT * FROM tbl_payments WHERE user_id='$smaconbotUser'");
	$invTotal = 0;
	$totalInvestment = 0;
	while($investment = mysqli_fetch_assoc($queryPay)){
		$invTotal = $invTotal+1;
		$totalInvestment = $totalInvestment+$investment['bch_amount'];
	}
	$servFee = (0.05*$totalInvestment);
	$totalInvestment = $totalInvestment-$servFee;
?>
<h3> Total Investment (<?php print $invTotal; ?>)</h3>
<h1><?php print $totalInvestment; ?><sup><small class="text-white">BCH</small></sup></h1>
<p class="text-bold text-white">Total investment made on SmaconBot.</p>