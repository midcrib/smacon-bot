<?php
	$dir = '../../';
	require_once($dir.'connection.php');
	
	$queryInvestment = mysqli_query($conn, "SELECT * FROM tbl_payments WHERE user_id='$smaconbotUser'");
	$invTotal = 0;
	$totalInvestment = 0;
	while($investment = mysqli_fetch_assoc($queryInvestment)){
		$invTotal = $invTotal+1;
		$totalInvestment = $totalInvestment+$investment['bch_amount'];
	}
	$servFee = (0.05*$totalInvestment);
	$totalInvestment = $totalInvestment-$servFee;


	$queryPay = mysqli_query($conn, "SELECT * FROM tbl_mass_payouts WHERE user_id='$smaconbotUser'");
	$payTotal = 0;
	$totalPayouts = 0;
	while($payout = mysqli_fetch_assoc($queryPay)){
		$totalPayouts = $totalPayouts+$payout['amount'];
	}
	
	$currentBalance = $totalInvestment-$totalPayouts;
?>
<h3> Current Balance</h3>
<h1><?php print $currentBalance; ?><sup><small class="text-white">BCH</small></sup></h1>
<p class="text-bold text-white">Currently in your wallet</p>