<?php
	$dir = '../../';
	require_once($dir.'connection.php');
	$queryPay = mysqli_query($conn, "SELECT * FROM tbl_payments WHERE user_id='$smaconbotUser'");
	$invTotal = 0;
	$totalInvestment = 0;
	$totalEarning = 0;
	while($investment = mysqli_fetch_assoc($queryPay)){
		$invTotal = $invTotal+1;
		$totalInvestment = $totalInvestment+$investment['bch_amount'];
	}
	$servFee = 0.05*$totalInvestment;
	$totalEarning = $totalInvestment-$servFee;
	$totalEarning = $totalEarning+(0.4*$totalEarning);

	$dailyEarning = $totalEarning/48;
	$dailyEarning = round($dailyEarning,5);
?>
<h3>Daily Earning</h3>
<h1><?php print $dailyEarning; ?><sup><small class="text-white">BCH</small></sup></h1>
<p class="text-bold text-white">Expected Daily Earnin</p>