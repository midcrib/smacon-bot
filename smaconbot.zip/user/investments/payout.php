<?php
	$dir = '../../';
	require_once($dir.'connection.php');
	$queryPay = mysqli_query($conn, "SELECT * FROM tbl_mass_payouts WHERE user_id='$smaconbotUser'");
	$payTotal = 0;
	$totalPayouts = 0;
	while($payout = mysqli_fetch_assoc($queryPay)){
		$payTotal = $payTotal+1;
		$totalPayouts = $totalPayouts+$payout['amount'];
	}

?>
<h3> Total Payouts(<?php print $payTotal; ?>)</h3>
<h1><?php print $totalPayouts; ?><sup><small class="text-white">BCH</small></sup></h1>
<p class="text-bold text-white">All payments received from SmaconBot</p>