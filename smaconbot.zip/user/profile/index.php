﻿<?php
	$dir = '../';
	$pageDir = '../../';
	require_once($dir.'connection.php');
	
?>