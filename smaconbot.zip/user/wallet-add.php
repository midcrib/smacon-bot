<?php	
	$title = 'Add Wallet Address | ';
	
	if(isset($_POST['saveAddress'])){
		$type = mysqli_real_escape_string($conn, $_POST['address_type']);
		$address = mysqli_real_escape_string($conn, $_POST['address']);
		$dateAdded = date("d-M-Y h:i:s a");
		
		if(!empty($address)){
			if(strlen($address)!= 42){
				$msg = '<h3 class="text-danger text-center"><i class="fa fa-times"></i> Invalid BCH address entered. Please check the address and try again.</h3>';
			}
			else{
				$insertAddr = mysqli_query($conn, "INSERT INTO tbl_usr_address(user_id,address,added,last_update,last_updated_ip)
					VALUES('$smaconbotUser', '$address', '$dateAdded', 'Not Updated Yet', 'None')");
				
				if($insertAddr === true){
					$msg = '<h3 class="text-success text-center"><i class="fa fa-check"></i> Address successfully added</h3>';
				}
				else{
					$msg = '<h3 class="text-danger text-center"><i class="fa fa-times"></i> Could not add wallet address. Try again later. ('.mysqli_error($conn).').</h3>';
				}
			}
		}
		else{
			$addr_error = '<span class="text-danger"><i class="fa fa-times"></i> Address is required!</span>';
		}
	}
	
	
	/////update wallet address///////
?>
<?php include($dir.'header.php'); ?>
          <!-- PAGE CONTENT -->
          <div class="right_col" role="main">
            <div class="spacer_30"></div>
            <div class="header-title-breadcrumb element-box-shadow">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12 text-left">
                          <h3>Update Wallet</h3>
						  <?php print $msg; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="spacer_30"></div>
            <div class="clearfix"></div>
            <div class="container">
              <div class="row">
                <div class="col-md-10 col-lg-8">
                  <!--Personal details-->
                  <div class="panel panel-cryptic element-box-shadow">
                    <div class="panel-heading padding_30">
                      <h3 class="no-margin">My Wallet Details</h3>
                    </div>
                    <div class="panel-body padding_30">
                      <form class="form-horizontal" method="post">
                        <fieldset>
                          <div class="form-group">
                            <label for="inputFirstName" class="col-lg-12 control-label">Currency</label>
                            <div class="col-lg-12">
                              <select class="form-control" name="address_type">
								<option selected="selected" value="BCH">Bitcoin Cash</option>
							  </select>
                            </div>
                          </div>
                          <div class="form-group">
                            <label for="inputLastName" class="col-lg-12 control-label">Address</label>
                            <div class="col-lg-12">
                              <input class="form-control input-type-1" name="address" id="inputLastName" value="<?php print $_POST['address']; ?>" placeholder="Enter your BCH address" type="text">
							  <?php print $addr_error; ?>
							</div>
                          </div>
						  <button class="btn btn-success" type="submit" name="saveAddress"><i class="fa fa-save"></i> Save Address</button>
                        </fieldset>
                      </form>
                    </div><!-- END panel-body -->
                  </div><!-- END Personal details-->
                  <!--Personal adderss-->
                  
                </div>
              </div>
            </div>
          </div>     